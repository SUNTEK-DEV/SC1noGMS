package com.sw.sdkapi.view.activity.hardware;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class CanAgeActivity extends BaseActivity {
    private final String TAG = CanAgeActivity.class.getSimpleName();

    @BindView(R.id.et_hardware_can_rate_slave)
    EditText etRate;
    @BindView(R.id.et_hardware_can_deviceid_slave)
    EditText etDeviceId;
    @BindView(R.id.et_hardware_can_send_data_times_slave)
    EditText etSendDataTimes;
    @BindView(R.id.tv_hardware_can_age_slave_tips)
    TextView tvTips;
    @BindView(R.id.et_hardware_can_send_data_offset_slave)
    EditText etOffsetTime;

    private int canId = -1;

    private boolean isReceiveWorking = false;  //是否在老化
    private boolean isSendWorking = false;

    private long offsetTime = 1000;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_can_age_slave);
    }

    @Override
    protected void onResume() {
        super.onResume();

        isReceiveWorking = false;
        isSendWorking = false;
//        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        closeCan();

        finish();
    }

    @OnClick({R.id.btn_back_hardware_can_slave, R.id.btn_hardware_can_open_slave, R.id.btn_hardware_can_close_slave,
            R.id.btn_hardware_can_age_receive_slave, R.id.btn_hardware_can_age_send_slave, R.id.btn_hardware_can_age_stop_slave})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_can_slave: {
                finish();
            }
            break;
            case R.id.btn_hardware_can_config_slave: {
                String rate = etRate.getText().toString();
                if (TextUtils.isEmpty(rate)) {
                    showToast("CAN总线速率不可为空");
                    return;
                }

                try {
                    int ret = SdkApi.getInstance().Hardware().canBusConfigUp(Integer.parseInt(rate));
                    if (ret == 0) {
                        showToastShort("CAN总线速率配置成功");
                    } else {
                        showToastShort("CAN总线速率配置失败");
                    }
                } catch (Exception e) {
                    showToastShort("CAN总线速率配置失败");
                }
            }
            break;
            case R.id.btn_hardware_can_open_slave: {
                String deviceId = etDeviceId.getText().toString();
                if (TextUtils.isEmpty(deviceId)) {
                    showToast("DeviceId不可为空");
                    return;
                }

                if (canId > 0) {
                    showToastShort("CAN已经打开");
                    return;
                }

                try {
                    canId = SdkApi.getInstance().Hardware().canOpen(Integer.parseInt(deviceId));
                    if (canId > 0) {
                        showToastShort("CAN打开成功 id = " + canId);
                    } else {
                        showToastShort("CAN打开失败");
                    }
                } catch (Exception e) {
                    showToastShort("CAN打开失败");
                }
            }
            break;
            case R.id.btn_hardware_can_close_slave: {
                closeCan();
            }
            break;
            case R.id.btn_hardware_can_age_receive_slave:{
                if(isReceiveWorking){
                    return;
                }

                try {
                    offsetTime = Integer.parseInt(etOffsetTime.getText().toString());
                    if(offsetTime <= 0){
                        offsetTime = 1000;
                    }

                    Toast.makeText(this, "老化时间间隔是" + offsetTime + "毫秒", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    offsetTime = 1000;
                }

                isReceiveWorking = true;
                new Thread(runnable).start();
            }
            break;
            case R.id.btn_hardware_can_age_send_slave:{
                if(isSendWorking){
                    return;
                }

                try {
                    offsetTime = Integer.parseInt(etOffsetTime.getText().toString());
                    if(offsetTime <= 0){
                        offsetTime = 1000;
                    }
                }catch (Exception e){
                    offsetTime = 1000;
                }

                try {
                    sendDataTimesMax = Integer.parseInt(etSendDataTimes.getText().toString());
                    if(sendDataTimesMax <= 0){
                        sendDataTimesMax = 10000;
                    }
                }catch (Exception e){
                    sendDataTimesMax = 10000;
                }

                Toast.makeText(this, "老化时间间隔: " + offsetTime + "毫秒", Toast.LENGTH_SHORT).show();

                isSendWorking = true;
                new Thread(sendRunnable).start();
            }
            break;
            case R.id.btn_hardware_can_age_stop_slave:{
                isSendWorking = false;
                isReceiveWorking = false;

                closeCan();
                resetData();
            }
            break;
        }
    }

    private void closeCan(){
        if (canId <= 0) {
            showToastShort("CAN没有打开");
            return;
        }

        isSendWorking = false;
        isReceiveWorking = false;

        int ret = SdkApi.getInstance().Hardware().canClose(canId);
        if (ret == 0) {
            showToastShort("CAN关闭");
            canId = -1;
        } else {
            showToastShort("CAN关闭失败");
        }
    }

    private final int flag = 0;  //CAN_EFF_FLAG
    private final int frameId = 0x123;
    private final byte[] canData = {0x02, 0x04, 0x05, 0x11, 0x01, 0x03, 0x16, 0x17};

    private Runnable runnable = new Runnable() {
        private int[] recevieBuffer = new int[16];

        @Override
        public void run() {
            startAgeTime = SystemClock.uptimeMillis();

            while (isReceiveWorking){
                try {
                    Thread.sleep(offsetTime);
                } catch (InterruptedException e) {

                }

                if(canId <= 0){
                    continue;
                }

                int ret = SdkApi.getInstance().Hardware().canRecv(canId, recevieBuffer);
                if(ret > 2){
                    Log.i(TAG, "rece data len = " + ret);
                    if(ret != (canData.length + 2)){
                        receiveDataFailTimes++;
                    }else{
                        receiveDataTimes++;

                        boolean success = true;
                        for(int i = 2; i < ret; i++){
                            if((recevieBuffer[i] & 0xFF) != canData[i - 2]){
                                success = false;
                            }
                        }

                        if(!success){
                            receiveDataFailTimes++;
                        }
                    }
                }

                timerDisplayAgeInfo(false);
            }
        }
    };

    private Runnable sendRunnable = new Runnable() {

        @Override
        public void run() {

            boolean forceDisplay = true;

            while (isSendWorking){
                try {
                    Thread.sleep(offsetTime);
                } catch (InterruptedException e) {

                }

                if(canId <= 0){
                    continue;
                }

                if(sendDataTimes >= sendDataTimesMax){
                    if(forceDisplay){ //老化结束后，强制再刷新一次UI
                        forceDisplay = false;
                        timerDisplayAgeInfo(true);
                    }

                    continue;
                }

                sendDataTimes++;

                int ret = SdkApi.getInstance().Hardware().canSend(canId, flag, frameId, canData, canData.length);
                if(ret == 0){
//                    showToastShort("数据发送成功");
                }else{
//                    showToastShort("数据发送失败");
                    sendDataFailTimes++;
                }

                timerDisplayAgeInfo(false);
            }
        }
    };

    private void timerDisplayAgeInfo(boolean force){
        synchronized (CanAgeActivity.class){
            if(force || (SystemClock.uptimeMillis() / 1000) != lastUpdateUiTime){
                displayAgeInfo();
                lastUpdateUiTime = SystemClock.uptimeMillis() / 1000;
            }
        }
    }

    private long lastUpdateUiTime = 0;
    private long sendDataTimesMax = 10000;

    private long startAgeTime = 0;
    private long sendDataTimes = 0;
    private long receiveDataTimes = 0;
    private long sendDataFailTimes = 0;
    private long receiveDataFailTimes = 0;

    private void resetData(){
        sendDataTimes = 0;
        receiveDataTimes = 0;
        sendDataFailTimes = 0;
        startAgeTime = 0;
        receiveDataFailTimes = 0;
    }

    private void displayAgeInfo(){
        final String data = "最大老化次数：" + sendDataTimesMax + "\n"
                + "已老化时间：" + (SystemClock.uptimeMillis() - startAgeTime) + "\n"
                + "发送次数：" + sendDataTimes + "\n"
                + "接收次数：" + receiveDataTimes + "\n"
                + "发送失败次数：" + sendDataFailTimes + "\n"
                + "接收失败次数：" + receiveDataFailTimes;

        postUiRunnable(new Runnable() {
            @Override
            public void run() {
                tvTips.setText(data);
            }
        }, 0);
    }

}
