package com.sw.sdkapi.util;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
    /**
     * 获取U盘列表
     *
     * @param con
     * @return
     */
    public static List<String> getUSBPaths(Context con) {//反射获取路径
        String[] paths = null;
        List<String> data = new ArrayList();    // include sd and usb devices
        StorageManager storageManager = (StorageManager) con.getSystemService(Context.STORAGE_SERVICE);

        if (Build.VERSION.SDK_INT >= 23) {
            try {
                List<StorageVolume> volumeList = storageManager.getStorageVolumes();

                Class<?> storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
                //通过反射调用系统hide的方法
                Method getPath = storageVolumeClazz.getMethod("getPath");
                Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
                for (int i = 0; i < volumeList.size(); i++) {
                    StorageVolume storageVolume = volumeList.get(i);//获取每个挂载的StorageVolume

                    //通过反射调用getPath、isRemovable
                    String storagePath = (String) getPath.invoke(storageVolume); //获取路径
                    boolean isRemovableResult = (boolean) isRemovable.invoke(storageVolume);//是否可移除
                    if (isRemovableResult && storageVolume.getState().equals(Environment.MEDIA_MOUNTED)
                            && !storagePath.contains("emulated")) {
                        data.add(storagePath);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                paths = (String[]) StorageManager.class.getMethod("getVolumePaths", (Class<?>) null).invoke(storageManager, (Object) null);
                for (String path : paths) {
                    String state = (String) StorageManager.class.getMethod("getVolumeState", String.class).invoke(storageManager, path);
                    if (state.equals(Environment.MEDIA_MOUNTED) && !path.contains("emulated")) {
                        data.add(path);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //因为反射不能百分百获取到外接USB SD卡的路径
        data.add("/mnt/external_sd/");
        data.add("/mnt/usb_storage/");
        data.add("/mnt/usb_storage1/");
        data.add("/mnt/usb_storage2/");
        data.add("/mnt/usb_storage3/");
        data.add("/mnt/usb_storage4/");
        data.add("/mnt/usb_storage5/");
        data.add("/mnt/usb_storage6/");
        return data;
    }
}
