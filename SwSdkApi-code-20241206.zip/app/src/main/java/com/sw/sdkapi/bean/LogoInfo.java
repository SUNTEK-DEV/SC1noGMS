package com.sw.sdkapi.bean;

public class LogoInfo {
    private int type;  //0:animation  1:boot logo
    private String orientation;  //horizontal:横屏   vertical:竖屏
    private String logoFilePath;  //文件存放绝对路径
    private int logoFileType;  //0:png  1:zip  2:mp4

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getOrientation() {
        return orientation;
    }

    public void setOrientation(String orientation) {
        this.orientation = orientation;
    }

    public String getLogoFilePath() {
        return logoFilePath;
    }

    public void setLogoFilePath(String logoFilePath) {
        this.logoFilePath = logoFilePath;
    }

    public int getLogoFileType() {
        return logoFileType;
    }

    public void setLogoFileType(int logoFileType) {
        this.logoFileType = logoFileType;
    }

    @Override
    public String toString() {
        return "LogoInfo{" +
                "type=" + type +
                ", orientation='" + orientation + '\'' +
                ", logoFilePath='" + logoFilePath + '\'' +
                ", logoFileType=" + logoFileType +
                '}';
    }
}
