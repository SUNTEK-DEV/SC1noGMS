package com.sw.sdkapi;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ApiTool;
import com.sdkapi.common.ResultCallback;
import com.sdkapi.common.ResultInfo;
import com.sw.sdkapi.util.ApiConvertUtil;
import com.sw.sdkapi.util.SystemPropertiesInvoke;
import com.sw.sdkapi.util.SystemUtil;
import com.sw.sdkapi.R;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.annotation.Nullable;

import butterknife.BindView;
import butterknife.OnClick;

public class SystemCtrlActivity extends BaseActivity {
    private final String TAG = SystemCtrlActivity.class.getSimpleName();

    @BindView(R.id.et_screenshot_path)
    EditText etScreenshotPath;
    @BindView(R.id.spi_screenshot_select)
    Spinner spiScreenshot;
    @BindView(R.id.iv_screenshot)
    ImageView ivScreenshot;
    @BindView(R.id.et_sleep_time)
    EditText etSleepTime;
    @BindView(R.id.et_install_path)
    EditText etInstallPath;
    @BindView(R.id.et_uninstall_package_name)
    EditText etUninstallPackageName;
    @BindView(R.id.spi_install_select)
    Spinner spiInstall;

    @BindView(R.id.et_system_property)
    EditText etSystemProperty;
    @BindView(R.id.et_system_property_value)
    EditText etSystemPropertyValue;

    private int screenshotSelectPosition = -1;
    private int installSelectPosition = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_systemctrl);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }

    private boolean isDS950() {
        if ("Amlogic".equals(SystemPropertiesInvoke.get("ro.soc.manufacturer", ""))) {
            if (Build.MODEL.contains("950")) {//persist.vendor.sdkapk.hardwareBoard   ds950
                return true;
            }
        }
        return false;
    }

    @OnClick({R.id.btn_back_systemctrl,
            R.id.btn_ctrl_reboot, R.id.btn_ctrl_show_status_bar, R.id.btn_ctrl_hide_status_bar,
            R.id.btn_ctrl_get_status_bar_status, R.id.btn_ctrl_screen_shot, R.id.btn_ctrl_screen_shot_clear,
            R.id.btn_ctrl_shallow_on_off, R.id.btn_ctrl_get_shallow_on_off, R.id.btn_ctrl_deep_on_off, R.id.btn_ctrl_deep_off,
            R.id.btn_ctrl_fan_on, R.id.btn_ctrl_fan_off, R.id.btn_ctrl_get_fan_status,
            R.id.btn_ctrl_get_last_touch_time, R.id.btn_ctrl_install, R.id.btn_ctrl_uninstall,
            R.id.btn_set_system_property, R.id.btn_get_system_property, R.id.btn_hdmiin_screen_shot, R.id.btn_ctrl_format_local})
    public void onViewClicked(View view) {
        int viewId = view.getId();
        switch (viewId) {
            case R.id.btn_back_systemctrl: {
                finish();
            }
            break;
            case R.id.btn_ctrl_reboot: {
                SdkApi.getInstance().SystemCtrl().deviceReboot();
            }
            break;
            case R.id.btn_ctrl_show_status_bar: {
                SdkApi.getInstance().SystemCtrl().setStatusBarDisplay(true);
            }
            break;
            case R.id.btn_ctrl_hide_status_bar: {
                SdkApi.getInstance().SystemCtrl().setStatusBarDisplay(false);
            }
            break;
            case R.id.btn_ctrl_get_status_bar_status: {
                boolean ret = SdkApi.getInstance().SystemCtrl().getStatusBarDisplay();
                showToast("导航栏" + (ret ? "已显示" : "已隐藏"));
            }
            break;
            case R.id.btn_ctrl_format_local: {
                SdkApi.getInstance().SystemCtrl().formatStorageDevice(ApiTool.Format.Internal, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToast("格式化" + (val.getVal() ? "成功" : "失败"));
                    }
                });
            }
            break;
            case R.id.btn_ctrl_screen_shot: {
                final String path = etScreenshotPath.getText().toString();
                if (TextUtils.isEmpty(path)) {
                    showToast("截图路径为空");
                    return;
                }
                Log.i(TAG, "screen shot path = " + path);
                Log.i(TAG, "screen shot screenshotSelectPosition = " + screenshotSelectPosition);
                SdkApi.getInstance().SystemCtrl().shotScreen(path, screenshotSelectPosition, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        if (val == null) {
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToastShort("截屏：" + str);

                        displayScreenshotImage(5, path);
                    }
                });
            }
            break;
            case R.id.btn_ctrl_screen_shot_clear: {
                final String path = etScreenshotPath.getText().toString();
                if (TextUtils.isEmpty(path)) {
                    showToast("截图路径为空");
                    return;
                }
                Log.i(TAG, "onViewClicked: screen_shot_clear");
                File file = new File(path);
                if (file.exists()) {
                    file.setWritable(true);
                    Log.i(TAG, "delete screen shot file = " + path);
                    if (file.delete()) {
                        showToast("截图文件删除成功");
                    } else {
                        Log.e(TAG, "delete screen shot file failed");
                    }

                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            ivScreenshot.setBackgroundColor(Color.BLACK);
                        }
                    }, 100);
                } else {
                    Log.i(TAG, "onViewClicked: screen_shot_clear  !file.exists()");
                }
                Log.i(TAG, "onViewClicked: screen_shot_clear end");
            }
            break;
            case R.id.btn_hdmiin_screen_shot: {
                Log.i(TAG, "onViewClicked: shot Hdmi In shot ");
                String outputPath = "/sdcard/hdmiInScreen" + System.currentTimeMillis() + ".png";
                if (isDS950()) {
                    outputPath = "/sdcard/hdmiInScreen" + System.currentTimeMillis() + ".jpg";
                }
                final String final_outputPath = outputPath;
                Toast.makeText(this, "请切换至hdmiin app，否则无法进行hdmiIn截屏操作,截屏操作延时15s，图片存储路径：" + outputPath, Toast.LENGTH_SHORT
                ).show();
                new Thread(() -> {
                    try {
                        Thread.sleep(15 * 1000);
                        Log.i(TAG, "onViewClicked: shotHdmiInScreen");
                        if (isDS950()) {
                            SdkApi.getInstance().SystemCtrl().shotScreen(final_outputPath, screenshotSelectPosition, new ResultCallback<ResultInfo<Boolean>>() {
                                @Override
                                public void onMsg(ResultInfo<Boolean> val) {
                                    Log.i(TAG, "onMsg: show hdmi screent by shotScreen");
                                    if (val == null) {
                                        return;
                                    }
                                    String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                                    showToastShort("shotHdmiInScreen：" + str);

                                    displayScreenshotImage(5, final_outputPath);
                                }
                            });
                        } else {
                            SdkApi.getInstance().SystemCtrl().shotHdmiInScreen(final_outputPath, new ResultCallback<ResultInfo<Boolean>>() {
                                @Override
                                public void onMsg(ResultInfo<Boolean> val) {
                                    Log.i(TAG, "onMsg: show hdmi screen");
                                    if (val == null) {
                                        return;
                                    }
                                    //String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
//                                    showToastShort("shotHdmiInScreen：" + str);
                                    //displayScreenshotImage(5, final_outputPath);
                                }
                            });
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }).start();
            }
            break;
            case R.id.btn_ctrl_shallow_on_off: {
                final String str = etSleepTime.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToast("再开机时间为空");
                    return;
                }

                try {
                    int sleepTime = Integer.parseInt(str);
                    Log.i(TAG, "sleepTime = " + sleepTime);
                    if (sleepTime > 0) {
                        final long startTime = System.currentTimeMillis();
                        Log.i(TAG, "liufeng0814: ");
                        SdkApi.getInstance().SystemCtrl().setDeviceShallowOnoff(false);
                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                Log.i(TAG, "liufeng0814: " + (System.currentTimeMillis() - startTime));
                                SdkApi.getInstance().SystemCtrl().setDeviceShallowOnoff(true);
                            }
                        }, sleepTime * 1000);
                    }
                } catch (Exception e) {
                    showToast("再开机时间格式错误");
                }
            }
            break;
            case R.id.btn_ctrl_get_shallow_on_off: {
                boolean ret = SdkApi.getInstance().SystemCtrl().getDeviceShallowOnoff();
                showToast("当前假关机状态： " + (ret ? "已开机" : "已关机"));
            }
            break;
            case R.id.btn_ctrl_deep_on_off: {
                final String str = etSleepTime.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToast("再开机时间为空");
                    return;
                }

                try {
                    int sleepTime = Integer.parseInt(str);
                    Log.i(TAG, "sleepTime = " + sleepTime);

                    sleepTime = sleepTime / 60;

                    if (sleepTime <= 0) {
                        sleepTime = 1;
                    }

                    SdkApi.getInstance().SystemCtrl().setDeviceDeepStandby(sleepTime);
                } catch (Exception e) {
                    showToast("再开机时间格式错误");
                }
            }
            break;
            case R.id.btn_ctrl_deep_off: {
                SdkApi.getInstance().SystemCtrl().setDeviceDeepStandby();
            }
            break;
            case R.id.btn_ctrl_fan_on: {
                boolean ret = SdkApi.getInstance().SystemCtrl().setFanOnoff(true);
                showToast("设置风扇打开： " + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_ctrl_fan_off: {
                boolean ret = SdkApi.getInstance().SystemCtrl().setFanOnoff(false);
                showToast("设置风扇关闭： " + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_ctrl_get_fan_status: {
                boolean ret = SdkApi.getInstance().SystemCtrl().getFanOnoff();
                showToast("风扇： " + (ret ? "已打开" : "已关闭"));
            }
            break;
            case R.id.btn_ctrl_get_last_touch_time: {
                long time = SdkApi.getInstance().SystemCtrl().getTPLastTouchTime();
                if (time <= 0) {
                    showToast("暂无人触摸");
                    return;
                }

                showToast("上一次触摸时间：" + new Date(time).toString());
            }
            break;
            case R.id.btn_ctrl_install: {
                final String path = etInstallPath.getText().toString();
                if (TextUtils.isEmpty(path)) {
                    showToast("待安装apk路径为空");
                    return;
                }

                if (!new File(path).exists()) {
                    showToastShort("待安装apk文件没找到");
                    return;
                }

                SdkApi.getInstance().SystemCtrl().silentInstallApk(path, (installSelectPosition == 0) ? true : false, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        if (val == null) {
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToastShort("APP安装：" + str);
                    }
                });
            }
            break;
            case R.id.btn_ctrl_uninstall: {
                final String packageName = etUninstallPackageName.getText().toString();
                if (TextUtils.isEmpty(packageName)) {
                    showToast("待卸载apk包名为空");
                    return;
                }

                if (!SystemUtil.isAppInstalled(getApplicationContext(), packageName)) {
                    showToast("待卸载apk 未安装");
                    return;
                }

                SdkApi.getInstance().SystemCtrl().silentUninstallApk(packageName, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        if (val == null) {
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToastShort("APP卸载：" + str);
                    }
                });
            }
            break;
            case R.id.btn_set_system_property: {
                String property = etSystemProperty.getText().toString();
                if (TextUtils.isEmpty(property)) {
                    showToast("系统属性节点为空");
                    return;
                }

                String value = etSystemPropertyValue.getText().toString();
                if (TextUtils.isEmpty(value)) {
                    showToast("系统属性Value为空");
                    return;
                }

                SdkApi.getInstance().DeviceInfo().setProperty(property, value);
                showToast("系统属性值 已经执行");
            }
            break;
            case R.id.btn_get_system_property: {
                String property = etSystemProperty.getText().toString();
                if (TextUtils.isEmpty(property)) {
                    showToast("系统属性节点为空");
                    return;
                }

                String value = SdkApi.getInstance().DeviceInfo().getProperty(property, "none");

                etSystemPropertyValue.setText(value);
                showToast("获取到的内容是" + value);
            }
            break;
        }
    }

    private void initView() {
        initScreenshotView();
        initInstallView();
    }

    private void initScreenshotView() {
        List<String> list = new ArrayList<String>();
        list.add("主屏");
        list.add("副屏");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiScreenshot.setAdapter(adapter);
        spiScreenshot.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                screenshotSelectPosition = position;
                Log.i(TAG, "screenshotSelectPosition = " + screenshotSelectPosition);//todo you bug
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiScreenshot.setSelection(0);
    }

    private void initInstallView() {
        List<String> list = new ArrayList<String>();
        list.add("自启APP");
        list.add("不自启APP");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiInstall.setAdapter(adapter);
        spiInstall.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                installSelectPosition = position;
                Log.i(TAG, "installSelectPosition = " + installSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiInstall.setSelection(1);
    }

    private void displayScreenshotImage(final int timeout, final String path) {
        int times = timeout - 1;
        if (times < 0) {
            showToast("超时，未读到截屏文件");
            return;
        }

        if (TextUtils.isEmpty(path)) {
            showToast("截图路径为空");
            return;
        }

        if (!new File(path).exists()) {
            postUiRunnable(new Runnable() {
                @Override
                public void run() {
                    displayScreenshotImage(times, path);
                }
            }, 1000);

            showToastShort("未找到截图图片，倒计时 " + times + "秒");
            return;
        }

        postUiRunnable(new Runnable() {
            @Override
            public void run() {
                ivScreenshot.setBackground(Drawable.createFromPath(path));
            }
        }, 100);
    }
}
