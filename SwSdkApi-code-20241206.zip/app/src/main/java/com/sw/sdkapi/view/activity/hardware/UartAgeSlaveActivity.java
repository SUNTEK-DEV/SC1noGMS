package com.sw.sdkapi.view.activity.hardware;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.sw.sdkapi.BaseActivity;
import com.sw.serial.SerialHelper;
import com.sw.sdkapi.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class UartAgeSlaveActivity extends BaseActivity {
    private final String TAG = UartAgeSlaveActivity.class.getSimpleName();

    @BindView(R.id.spi_uart_number_age_slave)
    Spinner spiNumber_1;   //串口号
    @BindView(R.id.spi_uart_baudRate_age_slave)
    Spinner spiBaudRate_1;   //波特率
    @BindView(R.id.spi_uart_data_age_slave)
    Spinner spiData_1;  //数据位
    @BindView(R.id.spi_uart_check_age_slave)
    Spinner spiCheck_1;  //校验位
    @BindView(R.id.spi_uart_stop_age_slave)
    Spinner spiStop_1;  //停止位
    @BindView(R.id.tv_hardware_uart_age_slage_tips)
    TextView tvTips_1;

    private SingleUartAgeSlave uartAgeSlave;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_uart_age_slave);

        uartAgeSlave = new SingleUartAgeSlave(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        uartAgeSlave.initView(spiNumber_1, spiBaudRate_1, spiData_1, spiCheck_1, spiStop_1);
    }

    @Override
    protected void onPause() {
        super.onPause();

        uartAgeSlave.closeSerial();

        finish();
    }

    @OnClick({R.id.btn_back_hardware_uart_age_slave,
            R.id.btn_hardware_uart_age_slave_start, R.id.btn_hardware_uart_age_slave_stop})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_uart_age_slave: {
                finish();
            }
            break;
            case R.id.btn_hardware_uart_age_slave_start:{
                if(uartAgeSlave.openSerial()){
                    showToastShort("串口打开成功，开始老化");

                    tvTips_1.setText("正在老化中...");
                    tvTips_1.setBackgroundColor(Color.GREEN);
                }
            }
            break;
            case R.id.btn_hardware_uart_age_slave_stop:{
                uartAgeSlave.closeSerial();
                tvTips_1.setText("老化停止");
                tvTips_1.setBackgroundColor(Color.WHITE);
            }
            break;
        }
    }

    private class SingleUartAgeSlave {
        private Context context;
        private boolean isStop = false;

        private Spinner spiNumber;   //串口号
        private Spinner spiBaudRate;   //波特率
        private Spinner spiData;  //数据位
        private Spinner spiCheck;  //校验位
        private Spinner spiStop;  //停止位

        private int numberSelectPosition = 0;
        private int baudRateSelectPosition = 0;
        private int dataSelectPosition = 0;
        private int checkSelectPosition = 0;
        private int stopSelectPosition = 0;

        private List<String> devNameList;
        private List<String> baudRateList;

        private SerialHelper serialHelper;

        public SingleUartAgeSlave(Context context){
            this.context = context;
        }

        public void initView(Spinner spiNumber, Spinner spiBaudRate, Spinner spiData,
                             Spinner spiCheck, Spinner spiStop){
            this.spiNumber = spiNumber;
            this.spiBaudRate = spiBaudRate;
            this.spiData = spiData;
            this.spiCheck = spiCheck;
            this.spiStop = spiStop;

            initNumberSelectView();
            initBaudRateSelectView();
            initDataSelectView();
            initCheckSelectView();
            initStopSelectView();
        }

        public boolean openSerial(){
            String devPath = devNameList.get(numberSelectPosition);
            int baud = Integer.parseInt(baudRateList.get(baudRateSelectPosition));

            if(serialHelper != null){
                return true;
            }

            serialHelper = new SerialHelper(devPath, baud, true) {
                @Override
                protected void onReceive(SerialHelper helper, byte[] buffer, int length) {
                    if(length <= 0){
                        return;
                    }

                    try {
                        helper.send(buffer, length);
                    }catch (Exception e){

                    }
                }
            };

            try {
                serialHelper.open();
                Log.i(TAG, "open serial success = " + devPath);
                isStop = false;

                return true;
            } catch (IOException e) {
                Log.e(TAG, "open serial fail = " + e.toString());
            }

            serialHelper = null;

            return false;
        }

        public void closeSerial(){
            if(serialHelper != null){
                serialHelper.close();
                serialHelper = null;
            }

            isStop = true;
        }

        private void initStopSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("1");
            list.add("1.5");
            list.add("2");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiStop.setAdapter(adapter);
            spiStop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    stopSelectPosition = position;
                    Log.i(TAG, "stopSelectPosition = " + stopSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiStop.setSelection(0);
        }

        private void initCheckSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("None");
            list.add("Even");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiCheck.setAdapter(adapter);
            spiCheck.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    checkSelectPosition = position;
                    Log.i(TAG, "checkSelectPosition = " + checkSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiCheck.setSelection(0);
        }

        private void initDataSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("5");
            list.add("6");
            list.add("7");
            list.add("8");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiData.setAdapter(adapter);
            spiData.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    dataSelectPosition = position;
                    Log.i(TAG, "dataSelectPosition = " + dataSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiData.setSelection(3);
        }

        private void initBaudRateSelectView(){
            baudRateList = new ArrayList<String>();
            baudRateList.add("9600");
            baudRateList.add("19200");
            baudRateList.add("38400");
            baudRateList.add("115200");
            baudRateList.add("1500000");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, baudRateList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiBaudRate.setAdapter(adapter);
            spiBaudRate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    baudRateSelectPosition = position;
                    Log.i(TAG, "baudRateSelectPosition = " + baudRateSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiBaudRate.setSelection(0);
        }

        private void initNumberSelectView(){
            devNameList = getAllUartDevicesPath();

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, devNameList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiNumber.setAdapter(adapter);
            spiNumber.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    numberSelectPosition = position;
                    Log.i(TAG, "numberSelectPosition = " + numberSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiNumber.setSelection(0);
        }

        private List<String> getAllUartDevicesPath(){
            List<String> list = new ArrayList<String>();

            final String rootPath = "/dev/";
            File dir = new File(rootPath);
            if(!dir.exists() || !dir.isDirectory()){
                return list;
            }

            String[] fileList = dir.list();
            if((fileList == null) || (fileList.length <= 0)){
                return list;
            }

            for(int i = 0; i < fileList.length; i++){
                String filename = fileList[i];
                if(filename.startsWith(".") || !filename.startsWith("tty")){
                    continue;
                }

                list.add(rootPath + filename);
            }

            return list;
        }

    }
}
