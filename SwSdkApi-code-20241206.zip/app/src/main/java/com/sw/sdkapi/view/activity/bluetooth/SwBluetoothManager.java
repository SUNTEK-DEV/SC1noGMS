package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class SwBluetoothManager implements BaseConfigCallback {

    private Context mContext;

    private static SwBluetoothManager bluetoothManager;
    /**
     * 蓝牙适配器
     */
    private BluetoothAdapter mBluetoothAdapter;
    /**
     * 蓝牙广播
     */
    private BluetoothReceiver mBluetoothReceiver;
    /**
     * 蓝牙开关回调
     */
    private StateSwitchCallback mStateSwitchCallback;
    /**
     * 扫描设备回调
     */
    private ScanCallback mScanCallback;
    /**
     * 连接设备回调
     */
//    private ConnectDeviceCallback mConnectBack;
    /**
     * 蓝牙服务回调
     */
//    private ServiceListenerCallback mListenerCallback;

    private List<BluetoothDeviceInfo> mDeviceList = new LinkedList<>();

    public static SwBluetoothManager getInstance() {
        if (bluetoothManager == null) {
            bluetoothManager = new SwBluetoothManager();
        }
        return bluetoothManager;
    }

    @Override
    public void onStateSwitch(int state) {
        if (mStateSwitchCallback == null) {
            return;
        }
        //todo 这个目前只有连接和断开连接，要不要把连接中和断开连接中也加入？？？，让用的地方自己去判断
        if (state == BluetoothAdapter.STATE_ON) {
            mStateSwitchCallback.onStateChange(true);
        } else if (state == BluetoothAdapter.STATE_OFF) {
            mStateSwitchCallback.onStateChange(false);
        }
    }

    @Override
    public void onScanStop() {
        if (mScanCallback == null) {
            return;
        }
        mScanCallback.onScanStop(mDeviceList);
    }

    @Override
    public void onFindDevice(BluetoothDevice device, int rssi) {
        if (mScanCallback == null) {
            return;
        }

        BluetoothDeviceInfo findDevice = null;
        //排除相同设备
        for (int i = 0; i < mDeviceList.size(); i++) {
            BluetoothDeviceInfo info = mDeviceList.get(i);
            if (device.getAddress().equals(info.device.getAddress())) {
                findDevice = info;
                break;
            }
        }

        if(findDevice != null){
            findDevice.rssi = rssi;
        }else{
            findDevice = new BluetoothDeviceInfo();
            findDevice.device = device;
            findDevice.rssi = rssi;

            mDeviceList.add(findDevice);
        }

        mScanCallback.onFindDevice(device, rssi);
    }

    @Override
    public void onConnect(BluetoothDevice device) {
        BluetoothUtil.connectBT(device);
    }

    public String getBtAddressByReflection() {
        return BluetoothUtil.getBtAddressByReflection();
    }

    /**
     * 初始化
     *
     * @param context
     * @return
     */
    public synchronized SwBluetoothManager init(Context context) {
        if (mContext == null && context != null) {
            mContext = context;
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//            Log.d("LQZ", "init bluetooth!");
            mBluetoothReceiver = new BluetoothReceiver(mContext, this);
        }

        return this;
    }

    public Context getContext() {
        return mContext;
    }

    /**
     * 开启蓝牙
     */
    public void enableBluetooth(StateSwitchCallback callback) {
        mStateSwitchCallback = callback;

        if (mBluetoothAdapter != null) {
            if (!mBluetoothAdapter.isEnabled()) {
                mBluetoothAdapter.enable();
                mStateSwitchCallback.onStateChange(true); //蓝牙打开，如果多次打开，会不断的返回这个结果
            } else {
                mStateSwitchCallback.onStateChange(true);
            }
        }
    }

    /**
     * 蓝牙是否打开
     *
     * @return true 已经打开，false 未打开
     */
    public boolean isBTEnable() {
        return mBluetoothAdapter.isEnabled();
    }

    /**
     * 设备是否支持蓝牙  true为支持
     *
     * @return
     */
    public boolean isSupportBlue() {
        return mBluetoothAdapter != null;
    }

    /**
     * 关闭蓝牙
     *
     * @param callback
     */
    public void disableBluetooth(StateSwitchCallback callback) {
        mStateSwitchCallback = callback;
        if (mBluetoothAdapter != null) {
            if (mBluetoothAdapter.isEnabled()) {
                mBluetoothAdapter.disable();
            } else {
                mStateSwitchCallback.onStateChange(false);
            }
        }
    }

    /**
     * 开始搜索蓝牙
     */
    public void Scan(ScanCallback scanCallback) {
        mScanCallback = scanCallback;
        if (mBluetoothAdapter != null) {
            if (mBluetoothAdapter.isDiscovering()) {
                return;
            }

            mDeviceList.clear();
            mScanCallback.onScanStart(mBluetoothAdapter.startDiscovery());
        }
    }

    public void stopScan(){
        if (mBluetoothAdapter != null) {
            mBluetoothAdapter.cancelDiscovery();
        }
    }


    public List<BluetoothDevice> getBondedDevices() {
        if (mBluetoothAdapter == null) {

            return null;
        }
        Set<BluetoothDevice> bondedDevices = mBluetoothAdapter.getBondedDevices();
        return new ArrayList(bondedDevices);
    }

    public List<BluetoothDeviceInfo> getmDeviceList() {
        return mDeviceList;
    }
}
