package com.sw.sdkapi.view.activity.hardware;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import androidx.annotation.Nullable;
import butterknife.OnClick;

public class UartActvity extends BaseActivity {
    private final String TAG = UartActvity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_uart);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @OnClick({R.id.btn_back_hardware_uart_main,
            R.id.btn_hardware_uart_func, R.id.btn_hardware_uart_age_host, R.id.btn_hardware_uart_age_slave})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_uart_main: {
                finish();
            }
            break;
            case R.id.btn_hardware_uart_func:{
                startActivity(new Intent(this, UartFuncActivity.class));
            }
            break;
            case R.id.btn_hardware_uart_age_host:{
                startActivity(new Intent(this, UartAgeActivity.class));
            }
            break;
            case R.id.btn_hardware_uart_age_slave:{
                startActivity(new Intent(this, UartAgeSlaveActivity.class));
            }
            break;
        }
    }

}
