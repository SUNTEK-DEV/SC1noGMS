package com.sw.sdkapi.view.activity.hardware;

import android.content.Context;
import android.os.Bundle;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

/**
 * Date: 2023/10/12 17:57
 * <p>
 * Description:串口功能测试页面
 */
public class UartFuncActivity extends BaseActivity {
    private final String TAG = UartActvity.class.getSimpleName();

    @BindView(R.id.tv_hardware_uart_receive_1)
    TextView tvReceiveData_1;
    @BindView(R.id.tv_hardware_uart_receive_2)
    TextView tvReceiveData_2;

    @BindView(R.id.spi_uart_number_1)
    Spinner spiNumber_1;   //串口号
    @BindView(R.id.spi_uart_baudRate_1)
    Spinner spiBaudRate_1;   //波特率
    @BindView(R.id.spi_uart_data_1)
    Spinner spiData_1;  //数据位
    @BindView(R.id.spi_uart_check_1)
    Spinner spiCheck_1;  //校验位
    @BindView(R.id.spi_uart_stop_1)
    Spinner spiStop_1;  //停止位

    @BindView(R.id.spi_uart_number_2)
    Spinner spiNumber_2;   //串口号
    @BindView(R.id.spi_uart_baudRate_2)
    Spinner spiBaudRate_2;   //波特率
    @BindView(R.id.spi_uart_data_2)
    Spinner spiData_2;  //数据位
    @BindView(R.id.spi_uart_check_2)
    Spinner spiCheck_2;  //校验位
    @BindView(R.id.spi_uart_stop_2)
    Spinner spiStop_2;  //停止位

    @BindView(R.id.et_hardware_uart_send_data_1)
    EditText etSendData_1;

    @BindView(R.id.et_hardware_uart_send_data_2)
    EditText etSendData_2;

    private SingleUart singleUart_1 = new SingleUart(this);
    private SingleUart singleUart_2 = new SingleUart(this);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_uart_func);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        singleUart_1.closeSerial();
        singleUart_2.closeSerial();

        finish();
    }

    @OnClick({R.id.btn_back_hardware_uart,
            R.id.btn_hardware_uart_open_1, R.id.btn_hardware_uart_open_2,
            R.id.btn_hardware_uart_close_1, R.id.btn_hardware_uart_close_2,
            R.id.btn_hardware_uart_send_1, R.id.btn_hardware_uart_send_2})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_uart: {
                finish();
            }
            break;
            case R.id.btn_hardware_uart_open_1:{
                singleUart_1.openSerial();
            }
            break;
            case R.id.btn_hardware_uart_open_2:{
                singleUart_2.openSerial();
            }
            break;
            case R.id.btn_hardware_uart_close_1:{
                singleUart_1.closeSerial();
            }
            break;
            case R.id.btn_hardware_uart_close_2:{
                singleUart_2.closeSerial();
            }
            break;
            case R.id.btn_hardware_uart_send_1:{
                String str = etSendData_1.getText().toString();

                if(TextUtils.isEmpty(str)){
                    showToastShort("待发送数据不可为空");
                    return;
                }

                singleUart_1.sendData(str.getBytes(), str.getBytes().length);
            }
            break;
            case R.id.btn_hardware_uart_send_2:{
                String str = etSendData_2.getText().toString();

                if(TextUtils.isEmpty(str)){
                    showToastShort("待发送数据不可为空");
                    return;
                }

                singleUart_2.sendData(str.getBytes(), str.getBytes().length);
            }
            break;
        }
    }

    private void initView(){
        singleUart_1.initView(spiNumber_1, spiBaudRate_1, spiData_1, spiCheck_1, spiStop_1, tvReceiveData_1);
        singleUart_2.initView(spiNumber_2, spiBaudRate_2, spiData_2, spiCheck_2, spiStop_2, tvReceiveData_2);
    }

    private class SingleUart {
        private Context context;
        private boolean isStop = false;

        private Spinner spiNumber;   //串口号
        private Spinner spiBaudRate;   //波特率
        private Spinner spiData;  //数据位
        private Spinner spiCheck;  //校验位
        private Spinner spiStop;  //停止位

        private TextView tvReceiveData;

        private int numberSelectPosition = 0;
        private int baudRateSelectPosition = 0;
        private int dataSelectPosition = 0;
        private int checkSelectPosition = 0;
        private int stopSelectPosition = 0;

        private List<String> devNameList;
        private List<String> baudRateList;

        private int serialId = -1;

        public SingleUart(Context context){
            this.context = context;
        }

        public void initView(Spinner spiNumber, Spinner spiBaudRate, Spinner spiData,
                             Spinner spiCheck, Spinner spiStop, TextView tvReceiveData){
            this.spiNumber = spiNumber;
            this.spiBaudRate = spiBaudRate;
            this.spiData = spiData;
            this.spiCheck = spiCheck;
            this.spiStop = spiStop;
            this.tvReceiveData = tvReceiveData;

            initNumberSelectView();
            initBaudRateSelectView();
            initDataSelectView();
            initCheckSelectView();
            initStopSelectView();
        }

        public void openSerial(){
            String devPath = devNameList.get(numberSelectPosition);
            int baud = Integer.parseInt(baudRateList.get(baudRateSelectPosition));

            if(serialId > 0){
                return;
            }

            serialId = SdkApi.getInstance().Hardware().openSerial(devPath, baud);
            if(serialId <= 0){
                showToastShort("串口打开失败：" + devPath);
                return;
            }

            showToastShort("串口打开成功");

            isStop = false;
            new Thread(runnable).start();
        }

        public void closeSerial(){
            if(serialId <= 0){
                return;
            }

            isStop = true;
        }

        public void sendData(byte[] buffer, int len){
            if(serialId <= 0){
                showToastShort("串口未打开");
                return;
            }

            int writeLen = SdkApi.getInstance().Hardware().writeSerial(serialId, buffer, len);
            if(writeLen != len){
                showToastShort("数据写失败 len = " + writeLen);
            }
        }

        private void initStopSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("1");
            list.add("1.5");
            list.add("2");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiStop.setAdapter(adapter);
            spiStop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    stopSelectPosition = position;
                    Log.i(TAG, "stopSelectPosition = " + stopSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiStop.setSelection(0);
        }

        private void initCheckSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("None");
            list.add("Even");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiCheck.setAdapter(adapter);
            spiCheck.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    checkSelectPosition = position;
                    Log.i(TAG, "checkSelectPosition = " + checkSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiCheck.setSelection(0);
        }

        private void initDataSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("5");
            list.add("6");
            list.add("7");
            list.add("8");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiData.setAdapter(adapter);
            spiData.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    dataSelectPosition = position;
                    Log.i(TAG, "dataSelectPosition = " + dataSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiData.setSelection(3);
        }

        private void initBaudRateSelectView(){
            baudRateList = new ArrayList<String>();
            baudRateList.add("9600");
            baudRateList.add("19200");
            baudRateList.add("38400");
            baudRateList.add("115200");
            baudRateList.add("1500000");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, baudRateList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiBaudRate.setAdapter(adapter);
            spiBaudRate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    baudRateSelectPosition = position;
                    Log.i(TAG, "baudRateSelectPosition = " + baudRateSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiBaudRate.setSelection(0);
        }

        private void initNumberSelectView(){
            devNameList = getAllUartDevicesPath();

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, devNameList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiNumber.setAdapter(adapter);
            spiNumber.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    numberSelectPosition = position;
                    Log.i(TAG, "numberSelectPosition = " + numberSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiNumber.setSelection(0);
        }

        private List<String> getAllUartDevicesPath(){
            List<String> list = new ArrayList<String>();

            final String rootPath = "/dev/";
            File dir = new File(rootPath);
            if(!dir.exists() || !dir.isDirectory()){
                return list;
            }

            String[] fileList = dir.list();
            if((fileList == null) || (fileList.length <= 0)){
                return list;
            }

            for(int i = 0; i < fileList.length; i++){
                String filename = fileList[i];
                if(filename.startsWith(".") || !filename.startsWith("tty")){
                    continue;
                }

                list.add(rootPath + filename);
            }

            return list;
        }

        private Runnable runnable = new Runnable() {
            private StringBuffer dataBuffer = new StringBuffer();

            @Override
            public void run() {
                dataBuffer.delete(0, dataBuffer.length());

                byte[] buffer = new byte[1024];

                while (!isStop){
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {

                    }

                    if(serialId <= 0){
                        continue;
                    }

                    int readLen = SdkApi.getInstance().Hardware().readSerial(serialId, buffer, 1024);
                    if(readLen > 0){
                        for(int i = 0; i < readLen; i++){
                            dataBuffer.append(Integer.toHexString(buffer[i] & 0xFF) + " ");
                        }
                        dataBuffer.append("\n");

                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                tvReceiveData.setText(dataBuffer.toString());
                                int offset = getTextViewContentHeight(tvReceiveData);//调用getTextViewContentHeight
                                if (offset > tvReceiveData.getHeight()) {
                                    tvReceiveData.scrollTo(0, offset - tvReceiveData.getHeight());
                                }
                            }
                        }, 0);
                    }
                }

                int ret = SdkApi.getInstance().Hardware().closeSerial(serialId);
                serialId = -1;

                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        showToastShort("串口关闭" + (ret == 0 ? "成功" : "失败"));
                    }
                }, 0);
            }

            /**
             * 获取TextView中内容的高度
             * @param textView
             * @return
             */
            public int getTextViewContentHeight(TextView textView) {
                Layout layout = textView.getLayout();
                int desired = layout.getLineTop(textView.getLineCount());
                int padding = textView.getCompoundPaddingTop() + textView.getCompoundPaddingBottom();
                return desired + padding;
            }
        };
    }
}
