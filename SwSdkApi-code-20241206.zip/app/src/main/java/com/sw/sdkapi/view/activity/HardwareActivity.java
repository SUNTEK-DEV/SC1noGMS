package com.sw.sdkapi.view.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ResultCallback;
import com.sdkapi.common.ResultInfo;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;
import com.sw.sdkapi.view.activity.hardware.CanActivity;
import com.sw.sdkapi.view.activity.hardware.GpioActivity;
import com.sw.sdkapi.view.activity.hardware.UartActvity;
import com.sw.sdkapi.view.activity.hardware.WiegandActivity;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class HardwareActivity extends BaseActivity {
    private final String TAG = HardwareActivity.class.getSimpleName();

    @BindView(R.id.tv_hardware_speaker_info)
    TextView tvSpeakerInfo;
    @BindView(R.id.spi_hardware_speaker_power_select)
    Spinner spiSpeakerPower;
    @BindView(R.id.spi_hardware_speaker_resistor_select)
    Spinner spiSpeakerResistor;
    @BindView(R.id.btn_volume_set)
    SeekBar sbVolumeSet;

    private MediaPlayer mediaPlayer = null;

    private int speakerPower = 0;
    private int speakerResistor = 0;

    private int speakerPowerSelectPosition = 0;
    private int speakerResistorSelectPosition = 0;

    private AudioManager mAudioManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @OnClick({R.id.btn_back_hardware, R.id.btn_hardware_gpio, R.id.btn_hardware_uart, R.id.btn_hardware_can,
            R.id.btn_play_1k_audio, R.id.btn_stop_1k_audio, R.id.btn_hardware_get_speaker_info,
            R.id.btn_hardware_set_speaker_info, R.id.btn_board_led_open, R.id.btn_board_led_close,
            R.id.btn_ir_r_led_open, R.id.btn_ir_r_led_close, R.id.btn_ir_g_led_open, R.id.btn_ir_g_led_close,
            R.id.btn_hardware_wiegand})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware: {
                finish();
            }
            break;
            case R.id.btn_hardware_gpio: {
                startActivity(new Intent(this, GpioActivity.class));
            }
            break;
            case R.id.btn_hardware_uart: {
                startActivity(new Intent(this, UartActvity.class));
            }
            break;
            case R.id.btn_hardware_can: {
                startActivity(new Intent(this, CanActivity.class));
            }
            break;
            case R.id.btn_hardware_wiegand: {
                startActivity(new Intent(this, WiegandActivity.class));
            }
            break;
            case R.id.btn_play_1k_audio: {
                try {
                    if (mediaPlayer == null) {
                        mediaPlayer = new MediaPlayer();

                        AssetFileDescriptor afd = getAssets().openFd("1kHz 0dB.mp3");
                        mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                        mediaPlayer.setLooping(true);
                        mediaPlayer.prepare();
                        mediaPlayer.start();

                        showToastShort("开始播放1K音频");
                    }else{
                        showToastShort("正在播放...");
                    }
                } catch (Exception e) {

                }
            }
            break;
            case R.id.btn_stop_1k_audio: {
                showToastShort("停止播放音频...");
                if(mediaPlayer != null){
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            }
            break;
            case R.id.btn_hardware_get_speaker_info:{
                SdkApi.getInstance().Hardware().getSpeakerConfigs(new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if (val != null) {
                            byte[] data = val.getArrayByte();
                            if ((data != null) && (data.length >= 3)) {
                                speakerPower = data[1];
                                speakerResistor = data[2];
                                Log.i(TAG, "speaker power = " + speakerPower + "; resistor = " + speakerResistor);

                                postUiRunnable(new Runnable() {
                                    @Override
                                    public void run() {
                                        tvSpeakerInfo.setText("喇叭功率:   " + speakerPower + "瓦  " + speakerResistor + "欧  ");
                                    }
                                }, 0);
                            }
                        }
                    }
                });
            }
            break;
            case R.id.btn_hardware_set_speaker_info:{
                int power = speakerPowerSelectPosition + 1;
                int resistor = (speakerResistorSelectPosition + 1) * 2;

                if (((power >= 1) && (power <= 10))
                        && ((resistor == 2) || (resistor == 4)
                        || (resistor == 6) || (resistor == 8))) {
                    boolean ret = SdkApi.getInstance().Hardware().setSpeakerConfigsSave(true, power, resistor);
                    showToast("设置喇叭功率" + (ret ? "成功" : "失败"));
                }else{
                    showToastShort("参数不支持");
                }
            }
            break;
            case R.id.btn_board_led_open:{
                SdkApi.getInstance().Hardware().setRunningLedOnoff(true, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
            case R.id.btn_board_led_close:{
                SdkApi.getInstance().Hardware().setRunningLedOnoff(false, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
            case R.id.btn_ir_r_led_open:{
                SdkApi.getInstance().Hardware().setKeyBoardLedROnoff(true, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
            case R.id.btn_ir_r_led_close:{
                SdkApi.getInstance().Hardware().setKeyBoardLedROnoff(false, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
            case R.id.btn_ir_g_led_open:{
                SdkApi.getInstance().Hardware().setKeyBoardLedGOnoff(true, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
            case R.id.btn_ir_g_led_close:{
                SdkApi.getInstance().Hardware().setKeyBoardLedGOnoff(false, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        showToastShort("已设置");
                    }
                });
            }
            break;
        }
    }

    private void initView(){
        initSpeakerPowerView();
        initSpeakerResistorView();

        mAudioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        sbVolumeSet.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int max = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

                int curr = (int)(progress * 1.0f / 100 * max);

                mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, curr, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        int max = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curr = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        sbVolumeSet.setProgress((int)(curr * 1.0f / max * 100));
    }

    private void initSpeakerPowerView(){
        List<String> list = new ArrayList<String>();
        list.add("1瓦");
        list.add("2瓦");
        list.add("3瓦");
        list.add("4瓦");
        list.add("5瓦");
        list.add("6瓦");
        list.add("7瓦");
        list.add("8瓦");
        list.add("9瓦");
        list.add("10瓦");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiSpeakerPower.setAdapter(adapter);
        spiSpeakerPower.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                speakerPowerSelectPosition = position;
                Log.i(TAG, "speakerPowerSelectPosition = " + speakerPowerSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiSpeakerPower.setSelection(0);
    }

    private void initSpeakerResistorView(){
        List<String> list = new ArrayList<String>();
        list.add("2欧");
        list.add("4欧");
        list.add("6欧");
        list.add("8欧");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiSpeakerResistor.setAdapter(adapter);
        spiSpeakerResistor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                speakerResistorSelectPosition = position;
                Log.i(TAG, "speakerResistorSelectPosition = " + speakerResistorSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiSpeakerResistor.setSelection(0);
    }
}
