package com.sw.sdkapi.view.activity.bluetooth;

public interface StateSwitchCallback {

    /**
     * true 开启
     * false 关闭
     * @param isOn 蓝牙开关状态
     */
    void onStateChange(boolean isOn);
}
