package com.sw.sdkapi;

import android.os.Bundle;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ScaleListener;
import com.sw.sdkapi.R;

import butterknife.OnClick;

public class ScalerActivity extends BaseActivity {
    int pid = Process.myPid();
    private static final String TAG = "ScalerActivity";

    public static final int SCALE_EVENT_REPORT_SCREEN_TYPE = 0x300D;
    public static final int SCALE_EVENT_REPORT_SCREEN_VOLUME = 0x300E;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scaler);
        SdkApi.getInstance().Scale().registerScaleListener(pid, scaleListener);
    }

    ScaleListener scaleListener = new ScaleListener() {
        @Override
        public void onNotify(int actionId, byte[] dataArray, int dataLen) {
            Log.i(TAG, "onNotify: actionId = " + actionId);
            Log.i(TAG, "onNotify: MainThread = " + (Thread.currentThread().getId() == Looper.getMainLooper().getThread().getId()));
            switch (actionId) {
                case SCALE_EVENT_REPORT_SCREEN_TYPE:
                    Log.i(TAG, "onNotify: SCREEN_TYPE dataArray[0] " + dataArray[0]);
                    //showToast();
                    break;
                case SCALE_EVENT_REPORT_SCREEN_VOLUME:
                    Log.i(TAG, "onNotify: SCREEN_VOLUME dataArray[0] " + dataArray[0]);
                    break;
            }
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SdkApi.getInstance().Scale().unregisterScaleListener(pid);
    }

    @OnClick({R.id.btn_back_scaler})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_scaler: {
                finish();
            }
            break;
        }
    }
}
