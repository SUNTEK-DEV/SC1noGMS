package com.sw.sdkapi.view.activity.hardware;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class CanFuncActivity extends BaseActivity {
    private final String TAG = CanFuncActivity.class.getSimpleName();

    @BindView(R.id.tv_hardware_can_receive)
    TextView tvReceiveData;
    @BindView(R.id.et_hardware_can_rate)
    EditText etRate;
    @BindView(R.id.et_hardware_can_deviceid)
    EditText etDeviceId;
    @BindView(R.id.et_hardware_can_send_data)
    EditText etSendData;

    private int canId = -1;

    private boolean isStop = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_can_func);
    }

    @Override
    protected void onResume() {
        super.onResume();

        isStop = false;
//        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        isStop = true;

        finish();
    }

    @OnClick({R.id.btn_back_hardware_can, R.id.btn_hardware_can_open, R.id.btn_hardware_can_close, R.id.btn_hardware_can_send,
            R.id.btn_hardware_can_clear})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_can: {
                finish();
            }
            break;
            case R.id.btn_hardware_can_config: {
                String rate = etRate.getText().toString();
                if (TextUtils.isEmpty(rate)) {
                    showToast("CAN总线速率不可为空");
                    return;
                }

                try {
                    int ret = SdkApi.getInstance().Hardware().canBusConfigUp(Integer.parseInt(rate));
                    if (ret == 0) {
                        showToastShort("CAN总线速率配置成功");
                    } else {
                        showToastShort("CAN总线速率配置失败");
                    }
                } catch (Exception e) {
                    showToastShort("CAN总线速率配置失败");
                }
            }
            break;
            case R.id.btn_hardware_can_open: {
                String deviceId = etDeviceId.getText().toString();
                if (TextUtils.isEmpty(deviceId)) {
                    showToast("DeviceId不可为空");
                    return;
                }

                if (canId > 0) {
                    showToastShort("CAN已经打开");
                    return;
                }

                try {
                    canId = SdkApi.getInstance().Hardware().canOpen(Integer.parseInt(deviceId));
                    if (canId > 0) {
                        isStop = false;
                        new Thread(runnable).start();

                        showToastShort("CAN打开成功");
                    } else {
                        showToastShort("CAN打开失败");
                    }
                } catch (Exception e) {
                    showToastShort("CAN打开失败");
                }
            }
            break;
            case R.id.btn_hardware_can_close: {
                if (canId <= 0) {
                    showToastShort("CAN没有打开");
                    return;
                }

                isStop = true;

                int ret = SdkApi.getInstance().Hardware().canClose(canId);
                if (ret == 0) {
                    showToastShort("CAN关闭");
                    canId = -1;
                } else {
                    showToastShort("CAN关闭失败");
                }
            }
            break;
            case R.id.btn_hardware_can_send: {
                String data = etSendData.getText().toString();
                if (TextUtils.isEmpty(data)) {
                    showToastShort("待发送数据为空");
                    return;
                }

                if (canId <= 0) {
                    showToastShort("CAN没有打开");
                    return;
                }

                int flag = 0;  //CAN_EFF_FLAG
                int frameId = 0x123;
                byte[] canData = data.getBytes();
                if(canData.length > 8){
                    canData = data.substring(0, 8).getBytes();
                }

                int ret = SdkApi.getInstance().Hardware().canSend(canId, flag, frameId, canData, canData.length);
                if(ret == 0){
                    showToastShort("数据发送成功");
                }else{
                    showToastShort("数据发送失败");
                }
            }
            break;
            case R.id.btn_hardware_can_clear:{
                clearBuffer();
                updateReceiveDataView("CAN收到的数据：");
            }
            break;
        }
    }

    private void updateReceiveDataView(final String data){
        postUiRunnable(new Runnable() {
            @Override
            public void run() {
                tvReceiveData.setText(data);
            }
        }, 0);
    }

    private StringBuffer dataBuffer = new StringBuffer();

    private Runnable runnable = new Runnable() {
        private int[] recevieBuffer = new int[16];

        @Override
        public void run() {
            clearBuffer();

            while (!isStop){
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {

                }

                if(canId <= 0){
                    continue;
                }

                int ret = SdkApi.getInstance().Hardware().canRecv(canId, recevieBuffer);
                if(ret > 0){
                    for(int i = 0; i < ret; i++){
                        dataBuffer.append(Integer.toHexString(recevieBuffer[2 + i] & 0xFF));
                    }
                    dataBuffer.append("\n");

                    updateReceiveDataView(dataBuffer.toString());
                }
            }
        }
    };

    private void clearBuffer(){
        dataBuffer.delete(0, dataBuffer.length());
        dataBuffer.append("CAN收到的数据：\n");
    }

}
