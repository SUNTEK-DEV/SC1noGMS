package com.sw.sdkapi.view.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import com.sw.sdkapi.R;

import androidx.annotation.NonNull;

/**
 * Date: 2022/9/22 17:49
 * <p>
 * Description:
 */
public class LoadingDialog extends Dialog {
    public LoadingDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_loading);
        this.setCanceledOnTouchOutside(false);
        this.setCancelable(false);


//        Window dialogWindow = getWindow();
//
//        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
//
//
//        lp.dimAmount= 1f;//外围遮罩透明度0.0f-1.0f
//        lp.width = Gravity.M
//        dialogWindow.setAttributes(lp);
//        dialogWindow.setDimAmount(1f);
//        dialogWindow.setGravity(Gravity.CENTER);//内围区域底部显示
    }
}
