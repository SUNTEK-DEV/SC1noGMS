package com.sw.sdkapi.bean;

import android.text.TextUtils;

import java.util.LinkedList;
import java.util.List;

public class AppData {

    public static List<String> actionNameList = new LinkedList<>();

    public static void addActionName(String name){
        if(!TextUtils.isEmpty(name)){
            actionNameList.add(name);
        }
    }
}
