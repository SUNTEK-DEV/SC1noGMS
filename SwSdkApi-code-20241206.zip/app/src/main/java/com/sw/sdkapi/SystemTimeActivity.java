package com.sw.sdkapi;

import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.R;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class SystemTimeActivity extends BaseActivity {
    private final String TAG = SystemTimeActivity.class.getSimpleName();

    @BindView(R.id.et_system_time)
    EditText etSystemTime;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_systemtime);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }

    @OnClick({R.id.btn_back_systemtime,
            R.id.btn_set_system_time, R.id.btn_get_system_time, R.id.btn_get_rtc_time, R.id.btn_get_run_time,
            R.id.btn_set_auto_time_on, R.id.btn_set_auto_time_off, R.id.btn_get_auto_time})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_systemtime: {
                finish();
            }
            break;
            case R.id.btn_set_system_time:{
                final String data = etSystemTime.getText().toString();
                if(TextUtils.isEmpty(data)){
                    showToast("时间数据不能为空");
                    return;
                }

                Date date;
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
                try{
                    date = sdf.parse(data);
                }catch (Exception e){
                    showToast("时间数据格式错误，yyyy/MM/dd hh:mm:ss");
                    return;
                }

                SdkApi.getInstance().SystemTime().setSystemTime(date.getTime());
                showToastShort("时间已设置：" + date.getTime());
            }
            break;
            case R.id.btn_get_system_time:{
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
                showToastShort("当前系统时间是：" + sdf.format(System.currentTimeMillis()));
            }
            break;
            case R.id.btn_get_rtc_time:{
                String str = SdkApi.getInstance().SystemTime().getRtcTime();

                showToastShort("RTC时间：" + str);
            }
            break;
            case R.id.btn_get_run_time:{
                showToastShort("系统已运行时间：" + (SystemClock.uptimeMillis() / 1000) + "秒");
            }
            break;
            case R.id.btn_set_auto_time_on:{
                SdkApi.getInstance().SystemTime().setAutoTimeOnoff(true);
                showToastShort("自动校准时间已打开");
            }
            break;
            case R.id.btn_set_auto_time_off:{
                SdkApi.getInstance().SystemTime().setAutoTimeOnoff(false);
                showToastShort("自动校准时间已关闭");
            }
            break;
            case R.id.btn_get_auto_time:{
                boolean ret = SdkApi.getInstance().SystemTime().getAutoTimeOnoff();
                showToastShort("自动校准时间" + (ret ? "已打开" : "已关闭"));
            }
            break;
        }
    }
}
