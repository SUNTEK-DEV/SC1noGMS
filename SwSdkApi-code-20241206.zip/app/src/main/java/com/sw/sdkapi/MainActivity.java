package com.sw.sdkapi;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ResultCallback;
import com.sdkapi.common.ResultInfo;
import com.sw.sdkapi.BuildConfig;
import com.sw.sdkapi.util.SystemPropertiesInvoke;
import com.sw.sdkapi.view.activity.AmlogicActivity;
import com.sw.sdkapi.view.activity.HardwareActivity;
import com.sw.sdkapi.view.activity.NetworkActivity;
import com.sw.sdkapi.view.activity.BluetoothActivity;
import com.sw.sdkapi.view.activity.gsensor.GsensorActivity;
import com.sw.sdkapi.view.widget.LoadingDialog;
import com.sw.sdkapi.R;
import butterknife.BindView;
import butterknife.OnClick;

public class MainActivity extends BaseActivity {

    private final String AppVersion = BuildConfig.ApiServiceVersion;

    @BindView(R.id.text_app_version)
    TextView tvAppVersion;
    @BindView(R.id.text_api_version)
    TextView tvApiVersion;
    @BindView(R.id.text_sdk_version)
    TextView tvSdkVersion;
    @BindView(R.id.text_firmware_version)
    TextView tvFirmwareVersion;
    @BindView(R.id.text_mcu_version)
    TextView tvMcuVersion;

    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SdkApi.newInstance(this);

        tvAppVersion.setText("App version: " + AppVersion);

        if (loadingDialog == null) {
            loadingDialog = new LoadingDialog(this, R.style.LoadingDialogTheme);
        }
        loadingDialog.show();

        connectTimeout = 0;
        postUiRunnable(getConnectRunnable(), 1000);
        tvFirmwareVersion.setText("固件版本：" + "None");
        tvMcuVersion.setText("MCU版本：" + "None");
        // 检查权限并请求
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
        } else {
            // 权限已经被授予，可以进行文件读写操作
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @OnClick({R.id.btn_base, R.id.btn_display, R.id.btn_system_ctrl, R.id.btn_timer_switch,
            R.id.btn_scaler, R.id.btn_hardware, R.id.btn_system_time,
            R.id.btn_other, R.id.btn_network, R.id.btn_bluetooth, R.id.btn_gsensor, R.id.btn_amlogic})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_base:
                startActivity(new Intent(this, BaseInfoActivity.class));
                break;
            case R.id.btn_display:
                startActivity(new Intent(this, DisplayActivity.class));
                break;
            case R.id.btn_system_ctrl:
                startActivity(new Intent(this, SystemCtrlActivity.class));
                break;
            case R.id.btn_timer_switch:
                startActivity(new Intent(this, TimerSwitchActivity.class));
                break;
            case R.id.btn_scaler:
                startActivity(new Intent(this, ScalerActivity.class));
                break;
            case R.id.btn_hardware:
                startActivity(new Intent(this, HardwareActivity.class));
                break;
            case R.id.btn_system_time:
                startActivity(new Intent(this, SystemTimeActivity.class));
                break;
            case R.id.btn_other:
                startActivity(new Intent(this, OtherActivity.class));
                break;
            case R.id.btn_network:
                startActivity(new Intent(this, NetworkActivity.class));
                break;
            case R.id.btn_bluetooth:
                startActivity(new Intent(this, BluetoothActivity.class));
                break;
            case R.id.btn_gsensor:
                startActivity(new Intent(this, GsensorActivity.class));
                break;
            case R.id.btn_amlogic:
                if ("Amlogic".equals(SystemPropertiesInvoke.get("ro.soc.manufacturer", ""))) {
                    startActivity(new Intent(this, AmlogicActivity.class));
                } else {
                    Toast.makeText(this, "not supported", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private int connectTimeout = 0;

    private Runnable getConnectRunnable() {
        return new Runnable() {
            @Override
            public void run() {
                if (SdkApi.getInstance().getServiceConnectionStatus()) {
                    loadingDialog.cancel();
                    connectApiSuccess();
                } else {
                    connectTimeout++;
                    if (connectTimeout > 6) {
                        loadingDialog.cancel();
                        return;
                    }

                    postUiRunnable(getConnectRunnable(), 1000);
                }
            }
        };
    }

    private static final String TAG = "MainActivity";

    private void connectApiSuccess() {
        tvApiVersion.setText("Api version: " + SdkApi.getInstance().DeviceInfo().getApiVersion());
        tvSdkVersion.setText("Sdk version: " + SdkApi.getInstance().DeviceInfo().getApiSdkServiceVersion());

        tvFirmwareVersion.setText("固件版本：" + SdkApi.getInstance().DeviceInfo().getFirmwareVersion());

        SdkApi.getInstance().DeviceInfo().getMcuVersion(new ResultCallback<ResultInfo<String>>() {
            @Override
            public void onMsg(ResultInfo<String> val) {
                String version = "";
                Log.i(TAG, "onMsg: " + val.getStatus());
                switch (val.getStatus()) {
                    case "success":
                        version = val.getVal();
                        break;
                    case "fail":
                        version = FailText;
                        break;
                    case "not-support":
                        version = NotSupportText;
                        break;
                }
                final String ver = version;
                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        tvMcuVersion.setText("MCU版本：" + ver);
                    }
                }, 100);
            }
        });
    }
}