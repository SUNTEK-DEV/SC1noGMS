package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothA2dp;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHeadset;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class BluetoothReceiver extends BroadcastReceiver {

    private BaseConfigCallback mCallback;

    public BluetoothReceiver(Context context, BaseConfigCallback callback) {
        mCallback = callback;
        IntentFilter filter = new IntentFilter();
        //蓝牙开关状态
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        //蓝牙开始搜索
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        //蓝牙搜索结束
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);

        //蓝牙发现新设备（未配对）
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        //设备配对状态改变
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        //设备建立连接
        filter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
        //设备断开连接
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED);

        //BluetoothAdapter连接状态
        filter.addAction(BluetoothAdapter.ACTION_CONNECTION_STATE_CHANGED);
        //BluetoothHeadset连接状态
        filter.addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED);
        //BluetoothA2dp连接状态
        filter.addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED);

        context.registerReceiver(this, filter);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        BluetoothDevice dev;
        int state;
        if (action == null) {
            return;
        }
        /**
         * 蓝牙开关状态
         * state == 10 //蓝牙关闭
         * state == 12 //蓝牙打开
         * state == 13 //蓝牙正在关闭
         * state == 11 //蓝牙正在打开
         */
        switch (action) {
            case BluetoothAdapter.ACTION_STATE_CHANGED:
                state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, 0);

                mCallback.onStateSwitch(state);
                break;
            /**
             * 开始搜索蓝牙
             */
            case BluetoothAdapter.ACTION_DISCOVERY_STARTED:
                //日志 开始搜索蓝牙
                break;
            /**
             * 搜索结束
             */
            case BluetoothAdapter.ACTION_DISCOVERY_FINISHED:
                //日志 扫描蓝牙结束
                mCallback.onScanStop();

                break;
            /**
             * 发现新设备
             */
            case BluetoothDevice.ACTION_FOUND:
                dev = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                int rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE);
                mCallback.onFindDevice(dev, rssi);
                break;

            default:
                break;
        }
    }
}