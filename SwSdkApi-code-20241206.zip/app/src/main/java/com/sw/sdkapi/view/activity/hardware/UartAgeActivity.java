package com.sw.sdkapi.view.activity.hardware;

import android.content.Context;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class UartAgeActivity extends BaseActivity {
    private final String TAG = UartAgeActivity.class.getSimpleName();

    public final byte CommHead1 = (byte)0xAA;
    public final byte CommHead2 = (byte)0xBB;
    public final byte CommHead3 = (byte)0xCC;

    public final int BufferLenMax = 8*1024;

    @BindView(R.id.et_hardware_uart_send_data_age_host)
    EditText etSendData_1;

    @BindView(R.id.spi_uart_number_age_host)
    Spinner spiNumber_1;   //串口号
    @BindView(R.id.spi_uart_baudRate_age_host)
    Spinner spiBaudRate_1;   //波特率
    @BindView(R.id.spi_uart_data_age_host)
    Spinner spiData_1;  //数据位
    @BindView(R.id.spi_uart_check_age_host)
    Spinner spiCheck_1;  //校验位
    @BindView(R.id.spi_uart_stop_age_host)
    Spinner spiStop_1;  //停止位

    @BindView(R.id.tv_hardware_uart_age_host_tips)
    TextView tvAgeTips;

    private int ageMode = 0;  //老化模式
    private SingleUartAgeHost uartAgeHost;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_uart_age_host);

        uartAgeHost = new SingleUartAgeHost(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        uartAgeHost.initView(spiNumber_1, spiBaudRate_1, spiData_1, spiCheck_1, spiStop_1, tvAgeTips);
    }

    @Override
    protected void onPause() {
        super.onPause();

        uartAgeHost.closeSerial();

        finish();
    }

    @OnClick({R.id.btn_back_hardware_uart_age_host,
            R.id.btn_hardware_uart_age_mode_stop, R.id.btn_hardware_uart_age_mode_text, R.id.btn_hardware_uart_age_mode_16,
            R.id.btn_hardware_uart_age_mode_64, R.id.btn_hardware_uart_age_mode_128, R.id.btn_hardware_uart_age_mode_1024,
            R.id.btn_hardware_uart_age_mode_4096})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_uart_age_host: {
                finish();
            }
            break;
            case R.id.btn_hardware_uart_age_mode_stop:{
                uartAgeHost.closeSerial();
            }
            break;
            case R.id.btn_hardware_uart_age_mode_text: {
                String str = etSendData_1.getText().toString();

                if(TextUtils.isEmpty(str)){
                    showToastShort("待发送数据不可为空");
                    return;
                }

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(str.getBytes(), str.getBytes().length);
                ageMode = 0;
            }
            break;
            case R.id.btn_hardware_uart_age_mode_16:{
                byte[] buffer = getRandomData(16);

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(buffer, buffer.length);
                ageMode = 1;
            }
            break;
            case R.id.btn_hardware_uart_age_mode_64:{
                byte[] buffer = getRandomData(64);

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(buffer, buffer.length);
                ageMode = 2;
            }
            break;
            case R.id.btn_hardware_uart_age_mode_128:{
                byte[] buffer = getRandomData(128);

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(buffer, buffer.length);
                ageMode = 3;
            }
            break;
            case R.id.btn_hardware_uart_age_mode_1024:{
                byte[] buffer = getRandomData(1024);

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(buffer, buffer.length);
                ageMode = 4;
            }
            break;
            case R.id.btn_hardware_uart_age_mode_4096:{
                byte[] buffer = getRandomData(4096);

                if(!uartAgeHost.openSerial()){
                    return;
                }

                uartAgeHost.createSendData(buffer, buffer.length);
                ageMode = 5;
            }
            break;
        }
    }

    private String getAgeMode(){
        switch (ageMode){
            case 0:
                return "文本老化";
            case 1:
                return "16字节老化";
            case 2:
                return "64字节老化";
            case 3:
                return "128字节老化";
            case 4:
                return "1024字节老化";
            case 5:
                return "4096字节老化";
        }

        return "错误模式";
    }

    private byte[] getRandomData(int len){
        byte[] buffer = new byte[len];

        new Random().nextBytes(buffer);

        return buffer;
    }

    private class SingleUartAgeHost {
        private Context context;
        private boolean isStop = false;

        private Spinner spiNumber;   //串口号
        private Spinner spiBaudRate;   //波特率
        private Spinner spiData;  //数据位
        private Spinner spiCheck;  //校验位
        private Spinner spiStop;  //停止位

        private TextView tvAgeTips;

        private int numberSelectPosition = 0;
        private int baudRateSelectPosition = 0;
        private int dataSelectPosition = 0;
        private int checkSelectPosition = 0;
        private int stopSelectPosition = 0;

        private List<String> devNameList;
        private List<String> baudRateList;

        private int serialId = -1;

        private int sendDataLen = 0;
        private byte[] sendDataBuffer;

        public SingleUartAgeHost(Context context){
            this.context = context;
        }

        public void initView(Spinner spiNumber, Spinner spiBaudRate, Spinner spiData,
                             Spinner spiCheck, Spinner spiStop, TextView tvAgeTips){
            this.spiNumber = spiNumber;
            this.spiBaudRate = spiBaudRate;
            this.spiData = spiData;
            this.spiCheck = spiCheck;
            this.spiStop = spiStop;
            this.tvAgeTips = tvAgeTips;

            initNumberSelectView();
            initBaudRateSelectView();
            initDataSelectView();
            initCheckSelectView();
            initStopSelectView();
        }

        public boolean openSerial(){
            String devPath = devNameList.get(numberSelectPosition);
            int baud = Integer.parseInt(baudRateList.get(baudRateSelectPosition));

            if(serialId > 0){
                showToastShort("已经在执行老化，需先关闭前一次老化");
                return false;
            }

            serialId = SdkApi.getInstance().Hardware().openSerial(devPath, baud);
            if(serialId <= 0){
                showToastShort("串口打开失败：" + devPath);
                return false;
            }

            showToastShort("串口打开成功");

            resetData();
            displayAgeInfo();

            isStop = false;
            new Thread(runnable).start();

            return true;
        }

        public void closeSerial(){
            if(serialId <= 0){
                return;
            }

            isStop = true;
        }

        public void createSendData(byte[] buffer, int len){
            if(len <= 0){
                return;
            }

            sendDataBuffer = new byte[len + 5];
            sendDataBuffer[0] = (byte)0xAA;
            sendDataBuffer[1] = (byte)0xBB;
            sendDataBuffer[2] = (byte)0xCC;
            sendDataBuffer[3] = (byte)(len >> 8 & 0xFF);
            sendDataBuffer[4] = (byte)(len & 0xFF);
            System.arraycopy(buffer, 0, sendDataBuffer, 5, len);

            sendDataLen = len;

            Log.i(TAG, "create data = " + printHexString(sendDataBuffer, 5+len));
        }

        public boolean sendData(){
            if(serialId <= 0){
//                showToastShort("串口未打开");
                return false;
            }

            int writeLen = SdkApi.getInstance().Hardware().writeSerial(serialId, sendDataBuffer, sendDataBuffer.length);
            if(writeLen != sendDataBuffer.length){
//                showToastShort("数据写失败 len = " + writeLen);
                return false;
            }

            return true;
        }

        private void initStopSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("1");
            list.add("1.5");
            list.add("2");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiStop.setAdapter(adapter);
            spiStop.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    stopSelectPosition = position;
                    Log.i(TAG, "stopSelectPosition = " + stopSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiStop.setSelection(0);
        }

        private void initCheckSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("None");
            list.add("Even");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiCheck.setAdapter(adapter);
            spiCheck.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    checkSelectPosition = position;
                    Log.i(TAG, "checkSelectPosition = " + checkSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiCheck.setSelection(0);
        }

        private void initDataSelectView(){
            List<String> list = new ArrayList<String>();
            list.add("5");
            list.add("6");
            list.add("7");
            list.add("8");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, list);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiData.setAdapter(adapter);
            spiData.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    dataSelectPosition = position;
                    Log.i(TAG, "dataSelectPosition = " + dataSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiData.setSelection(3);
        }

        private void initBaudRateSelectView(){
            baudRateList = new ArrayList<String>();
            baudRateList.add("9600");
            baudRateList.add("19200");
            baudRateList.add("38400");
            baudRateList.add("115200");
            baudRateList.add("1500000");

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, baudRateList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiBaudRate.setAdapter(adapter);
            spiBaudRate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    baudRateSelectPosition = position;
                    Log.i(TAG, "baudRateSelectPosition = " + baudRateSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiBaudRate.setSelection(0);
        }

        private void initNumberSelectView(){
            devNameList = getAllUartDevicesPath();

            ArrayAdapter adapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, devNameList);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spiNumber.setAdapter(adapter);
            spiNumber.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    numberSelectPosition = position;
                    Log.i(TAG, "numberSelectPosition = " + numberSelectPosition);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            spiNumber.setSelection(0);
        }

        private List<String> getAllUartDevicesPath(){
            List<String> list = new ArrayList<String>();

            final String rootPath = "/dev/";
            File dir = new File(rootPath);
            if(!dir.exists() || !dir.isDirectory()){
                return list;
            }

            String[] fileList = dir.list();
            if((fileList == null) || (fileList.length <= 0)){
                return list;
            }

            for(int i = 0; i < fileList.length; i++){
                String filename = fileList[i];
                if(filename.startsWith(".") || !filename.startsWith("tty")){
                    continue;
                }

                list.add(rootPath + filename);
            }

            return list;
        }

        private long sendDataTimes = 0;     //发送数据次数
        private long receiveDataTimes = 0;  //接收到的完整数据次数
        private long errorDataTimes = 0;    //错误数据次数
        private long startAgeTime = 0;      //开始老化时间

        private void resetData(){
            sendDataTimes = 0;
            receiveDataTimes = 0;
            errorDataTimes = 0;
            startAgeTime = 0;
        }

        private Runnable runnable = new Runnable() {
            public byte[] dataBuffer = new byte[BufferLenMax];
            public int currDataBufferLen = 0;

            private long lastSendTime = 0;
            private long offsetTime = 1000;

            @Override
            public void run() {
                byte[] buffer = new byte[4*1024];

                while (!isStop){
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {

                    }

                    if(serialId <= 0){
                        continue;
                    }

                    if((SystemClock.uptimeMillis() - lastSendTime) > offsetTime){
                        sendDataTimes++;

                        if(startAgeTime == 0){
                            startAgeTime = SystemClock.uptimeMillis();
                        }

                        sendData();
                        lastSendTime = SystemClock.uptimeMillis();

                        displayAgeInfo();
                    }

                    int readLen = SdkApi.getInstance().Hardware().readSerial(serialId, buffer, 4*1024);
                    if(readLen > 0){
                        if ((readLen + currDataBufferLen) > dataBuffer.length) {
                            readLen = dataBuffer.length - currDataBufferLen;
                        }

                        if (readLen > 0) {
                            System.arraycopy(buffer, 0, dataBuffer, currDataBufferLen, readLen);
                            currDataBufferLen += readLen;
                        }

                        Log.i(TAG, "receive data = " + printHexString(dataBuffer, currDataBufferLen));
                    }

                    if (currDataBufferLen > 0) {
                        uartAnalyseBuffer();
                    }
                }

                int ret = SdkApi.getInstance().Hardware().closeSerial(serialId);
                serialId = -1;

                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        showToastShort("串口关闭" + (ret == 0 ? "成功" : "失败"));
                    }
                }, 0);
            }

            private int uartAnalyseBuffer(){
                int offset = 0;

                //数据量太小，先不做分析
                if (currDataBufferLen < 5) {
                    return -1;
                }

                //找到协议头
                if ((dataBuffer[offset] != (byte) CommHead1)
                        || (dataBuffer[offset + 1] != (byte) CommHead2)
                        || (dataBuffer[offset + 2] != (byte) CommHead3)) {
                    while (offset < (currDataBufferLen - 1)) {
                        if ((dataBuffer[offset] == (byte) CommHead1)
                                && (dataBuffer[offset + 1] == (byte) CommHead2)
                                && (dataBuffer[offset + 2] == (byte) CommHead3))
                            break;
                        offset++;
                    }
                }

                if (offset >= (currDataBufferLen - 1)) {
                    Log.d(TAG, "Could Not Analyse mcu Comm Buffer\n");
                    updateCommBuffer(currDataBufferLen);
                    return -1;
                }

                int startOffset = offset;
                if((currDataBufferLen - startOffset) < 5){ //有效数据不满足一条完整指令
                    updateCommBuffer(startOffset);
                    return -1;
                }

                int dataLen = getDataLen(dataBuffer[startOffset + 3], dataBuffer[startOffset + 4]);
                if(sendDataLen != dataLen){
                    Log.i(TAG, "recevier data dataLen = " + dataLen);
                    updateCommBuffer(startOffset + 1);
                    return -1;
                }

                if((dataLen + 5) > BufferLenMax){
                    Log.i(TAG, "data length over max dataLen = " + dataLen);
                    updateCommBuffer(startOffset + 1);
                    return -1;
                }

                if((dataLen + 5) > (currDataBufferLen - startOffset)){
//                    Log.i(TAG, "data length less dataLen = " + dataLen + "; bufferLen = " + (currDataBufferLen - startOffset));
                    updateCommBuffer(startOffset - 1);
                    return -1;
                }

                boolean isSame = true;
                int start = startOffset;
                for(int i = start; i < (start + dataLen + 5); i++){
                    if((sendDataBuffer[i - start] & 0xFF) != (dataBuffer[i] & 0xFF)){
                        isSame = false;
                        break;
                    }
                }

                if(isSame){
                    receiveDataTimes++;
                }else{
                    errorDataTimes++;
                }
                lastSendTime = SystemClock.uptimeMillis() - offsetTime - 1;

                updateCommBuffer(startOffset + 5 + dataLen);
                Log.i(TAG, "currDataBufferLen = " + currDataBufferLen);

                displayAgeInfo();

                return 0;
            }

            public int getDataLen(byte high, byte low){
                return (high & 0xFF) << 8 | (low & 0xFF);
            }

            private int updateCommBuffer(int pos) {
                byte[] cbuffer = new byte[BufferLenMax];
                int up_len = 0;
                int i = 0;

                if ((pos < 0) || (pos >= BufferLenMax)) {
//                    Log.d(TAG, "Update Comm Buffer, pos error\n");
                    return -1;
                }

                up_len = currDataBufferLen - pos;
                if (up_len < 0) {
                    Log.d(TAG, "Update Comm Buffer, pos out off curr_len\n");
                    return -1;
                }

                if (up_len == 0) {
                    for (i = 0; i < currDataBufferLen; i++)
                        dataBuffer[i] = 0;
                    currDataBufferLen = 0;
                } else {
                    System.arraycopy(dataBuffer, pos, cbuffer, 0, up_len);
                    for (i = 0; i < currDataBufferLen; i++)
                        dataBuffer[i] = 0;
                    System.arraycopy(cbuffer, 0, dataBuffer, 0, up_len);
                    currDataBufferLen = up_len;
                }

                return 0;
            }
        };

        private void displayAgeInfo(){
            final String data = "老化模式：" + getAgeMode() + "\n"
                    + "已老化时间：" + (SystemClock.uptimeMillis() - startAgeTime) + "\n"
                    + "发送次数：" + sendDataTimes + "\n"
                    + "接收次数：" + receiveDataTimes + "\n"
                    + "错误次数：" + errorDataTimes;

            postUiRunnable(new Runnable() {
                @Override
                public void run() {
                    tvAgeTips.setText(data);
                }
            }, 0);
        }
    }

    private String printHexString(byte[] b, int length) {
        if (length > b.length) {
            return null;
        }
        StringBuilder buf = new StringBuilder();
        buf.append("[" + length + "]");
        for (int i = 0; i < length; i++) {
            String hex = Integer.toHexString(b[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            buf.append(hex.toUpperCase());
        }
        return buf.toString();
    }
}
