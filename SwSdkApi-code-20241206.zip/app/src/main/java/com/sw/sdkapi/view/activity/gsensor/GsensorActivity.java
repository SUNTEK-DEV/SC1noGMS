package com.sw.sdkapi.view.activity.gsensor;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import java.util.LinkedList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class GsensorActivity extends BaseActivity {
    private final String TAG = GsensorActivity.class.getSimpleName();

    @BindView(R.id.text_gsensor_switch)
    TextView tvSwitch;
    @BindView(R.id.btn_get_gsensor_page_1)
    Button btnGetPage1;
    @BindView(R.id.btn_get_gsensor_page_2)
    Button btnGetPage2;
    @BindView(R.id.btn_get_gsensor_page_3)
    Button btnGetPage3;
    @BindView(R.id.btn_get_gsensor_page_4)
    Button btnGetPage4;
    @BindView(R.id.btn_get_gsensor_page_5)
    Button btnGetPage5;
    @BindView(R.id.btn_get_gsensor_page_6)
    Button btnGetPage6;
    @BindView(R.id.text_gsensor_page_1_data)
    TextView tvPage1Data;
    @BindView(R.id.text_gsensor_page_2_data)
    TextView tvPage2Data;
    @BindView(R.id.text_gsensor_page_3_data)
    TextView tvPage3Data;
    @BindView(R.id.text_gsensor_page_4_data)
    TextView tvPage4Data;
    @BindView(R.id.text_gsensor_page_5_data)
    TextView tvPage5Data;
    @BindView(R.id.text_gsensor_page_6_data)
    TextView tvPage6Data;


    /*设置sensorManager*/
    public SensorManager sensorMgr = null;
    private Sensor sensor;
    private SensorEventListener sensorListener = null;

    private boolean isExistSensor = false;  //gsensor功能是否OK
    private boolean isStop = false;
    private int getDataStatus = 0;  //0:idle  1:getting  2:end

    private GsensorPage page1 = new GsensorPage();
    private GsensorPage page2 = new GsensorPage();
    private GsensorPage page3 = new GsensorPage();
    private GsensorPage page4 = new GsensorPage();
    private GsensorPage page5 = new GsensorPage();
    private GsensorPage page6 = new GsensorPage();

    private GsensorPage currentPage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gsensor);

        initView();
        boolean ret = initGsensor();
        tvSwitch.setText("Gsensor状态: " + (ret ? "可用" : "不可用"));
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "-->onResume");
        isStop = false;
    }

    @Override
    protected void onPause() {
        super.onPause();

        isStop = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if ((sensorMgr != null) && (sensorListener != null) && isExistSensor) {
            sensorMgr.unregisterListener(sensorListener);
            sensorListener = null;
        }
    }

    @OnClick({R.id.btn_back_gsensor, R.id.btn_get_gsensor_page_1, R.id.btn_get_gsensor_page_2,
            R.id.btn_get_gsensor_page_3, R.id.btn_get_gsensor_page_4,
            R.id.btn_get_gsensor_page_5, R.id.btn_get_gsensor_page_6,
            R.id.btn_stop_gsensor_page_1, R.id.btn_stop_gsensor_page_2,
            R.id.btn_stop_gsensor_page_3, R.id.btn_stop_gsensor_page_4,
            R.id.btn_stop_gsensor_page_5, R.id.btn_stop_gsensor_page_6})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_gsensor: {
                finish();
            }
            break;
            case R.id.btn_get_gsensor_page_1: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page1;
                currentPage.updateInitTips();
                updateGetDataBtnTips(btnGetPage1, "获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_1:{
                getDataStatus = 2;
                page1.calResult();
                updateGetDataBtnTips(btnGetPage1, "获取数据");
            }
            break;
            case R.id.btn_get_gsensor_page_2: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page2;
                currentPage.updateInitTips();
                currentPage.updateBtnStatus("获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_2:{
                getDataStatus = 2;
                page2.calResult();
                updateGetDataBtnTips(btnGetPage2, "获取数据");
            }
            break;
            case R.id.btn_get_gsensor_page_3: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page3;
                currentPage.updateInitTips();
                currentPage.updateBtnStatus("获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_3:{
                getDataStatus = 2;
                page3.calResult();
                updateGetDataBtnTips(btnGetPage3, "获取数据");
            }
            break;
            case R.id.btn_get_gsensor_page_4: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page4;
                currentPage.updateInitTips();
                currentPage.updateBtnStatus("获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_4:{
                getDataStatus = 2;
                page4.calResult();
                updateGetDataBtnTips(btnGetPage4, "获取数据");
            }
            break;
            case R.id.btn_get_gsensor_page_5: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page5;
                currentPage.updateInitTips();
                currentPage.updateBtnStatus("获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_5:{
                getDataStatus = 2;
                page5.calResult();
                updateGetDataBtnTips(btnGetPage5, "获取数据");
            }
            break;
            case R.id.btn_get_gsensor_page_6: {
                if(getDataStatus == 1){
                    return;
                }
                getDataStatus = 1;

                currentPage = page6;
                currentPage.updateInitTips();
                currentPage.updateBtnStatus("获取中");
            }
            break;
            case R.id.btn_stop_gsensor_page_6:{
                getDataStatus = 2;
                page6.calResult();
                updateGetDataBtnTips(btnGetPage6, "获取数据");
            }
            break;
        }
    }

    private void initView() {
        page1.setView(btnGetPage1, tvPage1Data);
        page1.updateInitTips();

        page2.setView(btnGetPage2, tvPage2Data);
        page2.updateInitTips();

        page3.setView(btnGetPage3, tvPage3Data);
        page3.updateInitTips();

        page4.setView(btnGetPage4, tvPage4Data);
        page4.updateInitTips();

        page5.setView(btnGetPage5, tvPage5Data);
        page5.updateInitTips();

        page6.setView(btnGetPage6, tvPage6Data);
        page6.updateInitTips();
    }

    private void updateGetDataBtnTips(Button btn, String tips) {
        btn.setText(tips);
    }

    /**
     * 初始化状态
     */
    private boolean initGsensor() {
        sensorMgr = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        assert sensorMgr != null;
        sensor = sensorMgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (sensor == null) {
            Log.e(TAG, "not get acceleromater sensor");
            return false;
        }

        isExistSensor = true;

        sensorListener = new SensorEventListener() {
            long lastDisplayTime = 0;

            @Override
            public void onSensorChanged(SensorEvent event) {
                if (isStop) {
                    return;
                }

                /*加速度传感器 状态不匹配，直接返回*/
                if (Sensor.TYPE_ACCELEROMETER != event.sensor.getType()) {
                    Log.e(TAG, "type not match");
                    return;
                }

                if(getDataStatus != 1){
                    return;
                }

                /*获得三维值*/
                float[] values = event.values;

                /*获得X*/
                float x = values[0];
                /*获得Y*/
                float y = values[1];
                /*获得Z*/
                float z = values[2];

                if(currentPage != null){
                    currentPage.addCoordinateData(new CoordinateBean(x, y, z));
                }

                //每隔200ms，刷新一次页面数据
                if(SystemClock.uptimeMillis() - lastDisplayTime > 200){
                    lastDisplayTime = SystemClock.uptimeMillis();

                    String data = "x = " + x + "\t\t" + "y = " + y + "\t\t" + "z = " + z;
                    if(currentPage != null){
                        currentPage.updateTips(data);
                    }
                }

                Log.i(TAG, "x = " + x + " " + "y = " + y + "z = " + z);
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };

        sensorMgr.registerListener(sensorListener, sensor, SensorManager.SENSOR_DELAY_GAME);
        return true;
    }

    private class GsensorPage{
        /*重力传感三维坐标值链表*/
        private List<CoordinateBean> coordinateList = new LinkedList<>();

        private Button btnGet;
        private TextView tvDisplay;

        private int totalCount = 0;
        private String realData = "";

        public void setView(Button btn, TextView tv){
            this.btnGet = btn;
            this.tvDisplay = tv;
        }

        public void updateInitTips(){
            totalCount = 0;
            realData = "";
            coordinateList.clear();

            String data = "收集数据组总数：" + 0;
            data += "\n";
            data += ("实时数据：");
            data += "\n";
            data += ("平均数据：");

            tvDisplay.setText(data);
        }

        public void updateBtnStatus(String data){
            btnGet.setText(data);
        }

        public synchronized void updateTips(String str){
            realData = str;

            String data = "收集数据组总数：" + totalCount;
            data += "\n";
            data += ("实时数据：" + realData);
            data += "\n";
            data += ("平均数据：");

            tvDisplay.setText(data);
        }

        public synchronized void addCoordinateData(CoordinateBean bean){
            totalCount++;
            String data = "收集数据组总数：" + totalCount;
            data += "\n";
            data += ("实时数据：" + realData);
            data += "\n";
            data += ("平均数据：");

            tvDisplay.setText(data);

            coordinateList.add(bean);
        }

        public synchronized void calResult(){
            float totalX = 0;
            float totalY = 0;
            float totalZ = 0;

            for(int i = 0; i < coordinateList.size(); i++){
                CoordinateBean bean = coordinateList.get(i);

                totalX += bean.getX();
                totalY += bean.getY();
                totalZ += bean.getZ();
            }

            float avaX = 0;
            float avaY = 0;
            float avaZ = 0;
            if(coordinateList.size() > 0){
                avaX = totalX / coordinateList.size();
                avaY = totalY / coordinateList.size();
                avaZ = totalZ / coordinateList.size();
            }

            String avaData = "x = " + avaX + "\t\t" + "y = " + avaY + "\t\t" + "z = " + avaZ;

            String data = "收集数据组总数：" + totalCount;
            data += "\n";
            data += ("实时数据：" + realData);
            data += "\n";
            data += ("平均数据：" + avaData);

            tvDisplay.setText(data);
        }
    }
}
