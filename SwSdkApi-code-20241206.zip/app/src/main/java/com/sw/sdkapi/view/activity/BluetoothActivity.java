package com.sw.sdkapi.view.activity;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.view.activity.bluetooth.SwBluetoothManager;
import com.sw.sdkapi.view.activity.bluetooth.StateSwitchCallback;
import com.sw.sdkapi.R;
import com.sw.sdkapi.view.activity.bluetooth.BluetoothDeviceInfo;
import com.sw.sdkapi.view.activity.bluetooth.ScanCallback;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import butterknife.BindView;
import butterknife.OnClick;

public class BluetoothActivity extends BaseActivity {
    private final String TAG = BluetoothActivity.class.getSimpleName();

    private final int REQUEST_CODE = 10001;

    @BindView(R.id.text_bluetooth_info)
    TextView tvLocalMac;
    @BindView(R.id.text_bluetooth_result)
    TextView tvResult;

    private boolean isStop = false;

    private String testBoardBuletoothMacAddress = "未获取";

    private Handler handler = new Handler();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth);

        initView();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_CODE); // REQUEST_CODE是你定义的int常量，用于识别请求结果
        }else{
            scanBluetooth();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限被授予，可以继续执行需要的蓝牙操作
                scanBluetooth();
            } else {
                // 权限被拒绝，需要提示用户或者采取其他措施
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "-->onResume");
        isStop = false;
    }

    @Override
    protected void onPause() {
        super.onPause();

        isStop = true;

        handler.removeCallbacksAndMessages(null);
        SwBluetoothManager.getInstance().stopScan();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @OnClick({R.id.btn_back_bluetooth})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_bluetooth: {
                finish();
            }
            break;
        }
    }

    private void initView(){
        tvLocalMac.setText("本设备蓝牙MAC: " + testBoardBuletoothMacAddress);  //获取蓝牙MAC
        tvResult.setText("已搜索到的蓝牙信息: 未搜索到");
    }

    private void updateTvContent(TextView view, final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                view.setText(str);
            }
        });
    }

    private synchronized void scanBluetooth() {
        testBoardBuletoothMacAddress = SwBluetoothManager.getInstance().getBtAddressByReflection();

        //获取蓝牙MAC
        updateTvContent(tvLocalMac, "本设备蓝牙MAC: " + testBoardBuletoothMacAddress);

        SwBluetoothManager.getInstance().init(getApplicationContext());
        //  判断蓝牙是否打开，未打开的话打开蓝牙，打开的话执行扫描
        SwBluetoothManager.getInstance().enableBluetooth(new StateSwitchCallback() {
            @Override
            public void onStateChange(boolean isOn) {
                if (isOn) {
                    Log.d(TAG, "蓝牙已经打开，执行扫描！");
                    SwBluetoothManager.getInstance().Scan(callback);
                }
            }
        });
    }

    private ScanCallback callback = new ScanCallback() {
        @Override
        public void onScanStart(boolean isOn) {

        }

        @Override
        public void onScanStop(List<BluetoothDeviceInfo> deviceList) {
            if(isStop){
                return;
            }

            // todo 扫描结束之后，如果有特定的设备，就变成连接，否则就是扫描结束
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    scanBluetooth();
                }
            }, 15*1000);
        }

        @Override
        public void onFindDevice(BluetoothDevice device, int rssi) {
            Log.i(TAG, "rssi = " + rssi + "; device = " + device.getName() + "; toString = " + device.toString());

            List<BluetoothDeviceInfo> infoList = SwBluetoothManager.getInstance().getmDeviceList();
            if((infoList == null) || (infoList.size() <= 0)){
                updateTvContent(tvResult, "已搜索到的蓝牙信息: 未搜索到");
                return;
            }

            String str = "已搜索到的蓝牙信息: \n";
            for(int i = 0; i < infoList.size(); i++){
                BluetoothDeviceInfo info = infoList.get(i);
                str += ("蓝牙" + (i + 1) + "\t\tMAC: " + info.device.toString()
                        + "\t\t[强度: " + info.rssi + "]"
                        + "\t\t[名字：" + info.device.getName() + "]");

                int bondState = info.device.getBondState();
                if(bondState == 11){
                    str += "\t\t[绑定中]";
                }else if(bondState == 12){
                    str += "\t\t[已绑定]";
                }

                str += "\n";
            }

            updateTvContent(tvResult, str);
        }
    };
}
