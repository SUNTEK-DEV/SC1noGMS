package com.sw.sdkapi.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * [功能简述] md5加密算法类
 *
 * @author MaNTy
 * @since Feb 11, 2011
 */
public class Md5Encript {
    /**
     * md5加密算法
     */
    public final static String ALGORITHMTYPE_MD5 = "MD5";

    /**
     * 加密参数
     */
    public final static String ALGORITHM_PARM = "99991231";

    /**
     * 字符集
     */
    public final static String ENCODING = "UTF-8";

    /**
     * 密文长度
     */
    public static final int LENGTH = 8;

    /**
     * 加密字符串最大长度
     */
    public static final int MAX_LENGTH = 32;

    /**
     * [功能简述] md5加密方法
     *
     * @param original
     * @return String
     */
    public static String md5Coding(String original) {
        return md5Coding(original, MAX_LENGTH);
    }

    /**
     * [功能描述] md5加密方法,使用了加密key
     *
     * @param original  加密字符串
     * @param retLength 返回长度
     */
    public static String md5Coding(String original, int retLength) {
        return md5Coding(original, retLength, null);
    }

    /**
     * [功能描述] md5加密方法,使用了加密key
     *
     * @param original      加密字符串
     * @param retLength     返回长度
     * @param algorithmParm 加密字符串
     */
    public static String md5Coding(String original, int retLength,
                                   String algorithmParm) {
        if (null == original) {
            return null;
        }

        if (retLength > MAX_LENGTH) {
            retLength = MAX_LENGTH;
        }

        String ret = null;
        String parm =/* StringUtil.isEmpty(algorithmParm) ? ALGORITHM_PARM
				: */algorithmParm;
        try {
            byte[] id = original.getBytes(ENCODING);
            MessageDigest md = MessageDigest.getInstance(ALGORITHMTYPE_MD5);
            md.update(id);
            md.update(parm.getBytes(ENCODING));
            byte[] buffer = md.digest();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < buffer.length; i++) {
                // byteVar & 0x000000FF的作用是，如果byteVar
                // 是负数，则会清除前面24个零，正的byte整型不受影响。
                // (...) | 0xFFFFFF00的作用是，如果byteVar 是正数，则置前24位为一，
                // 这样toHexString输出一个小于等于15的byte整型的十六进制时，倒数第二位为零且不会被丢弃，
                // 这样可以通过substring方法进行截取最后两位即可。
                sb.append(Integer.toHexString(
                        ((int) buffer[i] & 0x000000FF) | 0xFFFFFF00).substring(
                        6));
            }
            ret = sb.substring(0, retLength);
        } catch (UnsupportedEncodingException e) {
        } catch (IllegalStateException e) {
        } catch (NoSuchAlgorithmException e) {
        }
        return ret;
    }

    /**
     * 描述：直接从源串进行加密,不使用默认的加密参数进行加密
     *
     * @param original  加密啊字符串
     * @param retLength 返回长度
     * @return String
     */
    public static String directCoding(String original, int retLength) {
        if (null == original) {
            return null;
        }

        if (retLength > MAX_LENGTH) {
            retLength = MAX_LENGTH;
        }

        String ret = null;
        try {
            byte[] id = original.getBytes(ENCODING);
            MessageDigest md = MessageDigest.getInstance(ALGORITHMTYPE_MD5);
            md.update(id);
            byte[] buffer = md.digest();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < buffer.length; i++) {
                int value = (int) buffer[i] & 0xff;
                if (value < 0x10) {
                    sb.append('0');
                }
                sb.append(Integer.toHexString(value));
            }
            ret = sb.substring(0, retLength);
        } catch (UnsupportedEncodingException e) {
        } catch (IllegalStateException e) {
        } catch (NoSuchAlgorithmException e) {
        }
        return ret;
    }

    /**
     * 描述：直接从源byte数组进行加密,不使用默认的加密参数进行加密
     *
     * @param original  加密byte数组
     * @param retLength 返回长度
     * @return String
     */
    public static byte[] directCodingByte(byte[] original, int retLength) {
        if (null == original) {
            return null;
        }

        if (retLength > MAX_LENGTH) {
            retLength = MAX_LENGTH;
        }

        byte[] ret = null;
        try {
            MessageDigest md = MessageDigest.getInstance(ALGORITHMTYPE_MD5);
            md.update(original);
            ret = md.digest();
        } catch (IllegalStateException e) {
        } catch (NoSuchAlgorithmException e) {
        }
        return ret;
    }

    /**
     * MD5校验结果
     *
     * @param b 字节数据
     * @return MD5值返回结果
     */
    public static synchronized String getMD5String(byte[] b, int size) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(b, 0, size);
            byte[] buffer = md5.digest();

            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < buffer.length; i++) {
                int value = (int) buffer[i] & 0xff;
                if (value < 0x10) {
                    sb.append('0');
                }
                sb.append(Integer.toHexString(value));
            }

            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 对传递过来的字符串进行md5加密
     * @param str 待加密的字符串
     * @return 字符串Md5加密后的结果
     */
    public static String getMd5(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(str.getBytes(ENCODING));
            StringBuilder hexString = new StringBuilder();

            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }

            return hexString.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
