package com.sw.sdkapi.view.activity.hardware;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;

import butterknife.BindView;
import butterknife.OnClick;

public class GpioActivity extends BaseActivity {
    private final String TAG = GpioActivity.class.getSimpleName();

    @BindView(R.id.spi_gpio_output_group)
    Spinner spiOutputGroupSelect;
    @BindView(R.id.spi_gpio_output_number)
    Spinner spiOutputNumberSelect;
    @BindView(R.id.spi_gpio_output_value_select)
    Spinner spiOutputValueSelect;

    @BindView(R.id.spi_gpio_input_group)
    Spinner spiInputGroupSelect;
    @BindView(R.id.spi_gpio_input_number)
    Spinner spiInputNumberSelect;
    @BindView(R.id.tv_gpio_input_value)
    TextView tvInputValue;
    @BindView(R.id.et_gpio_num)
    TextView etGpioNum;
    @BindView(R.id.et_gpio_value)
    TextView etGpioValue;

    @BindView(R.id.ll_gpio)
    LinearLayout llGGpio;

    private int outputGroupSelectPosition = 0;
    private int outputNumberSelectPosition = 0;
    private int outputValueSelectPosition = 0;

    private int inputGroupSelectPosition = 0;
    private int inputNumberSelectPosition = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_gpio);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }

    @OnClick({R.id.btn_back_hardware_gpio, R.id.btn_gpio_input, R.id.btn_gpio_output, R.id.btn_gpio_set})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_gpio: {
                finish();
            }
            break;
            case R.id.btn_gpio_input: {
                int level = SdkApi.getInstance().Hardware().getGpioInput(inputGroupSelectPosition, inputNumberSelectPosition);
                if (level == -1) {
                    showToast("读取GPIO电平" + "失败");
                } else if (level == 0) {
                    tvInputValue.setText("低电平");
                    showToastShort("低电平");
                } else if (level == 1) {
                    tvInputValue.setText("高电平");
                    showToastShort("高电平");
                } else {
                    showToast("无效电平");
                }
            }
            break;
            case R.id.btn_gpio_output: {
                boolean ret = SdkApi.getInstance().Hardware().setGpioOutput(outputGroupSelectPosition,
                        outputNumberSelectPosition, (outputValueSelectPosition == 0) ? true : false);
                showToast("设置GPIO电平" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_gpio_set: {
                if (TextUtils.isEmpty(etGpioNum.getText()) || TextUtils.isEmpty(etGpioValue.getText())) {
                    showToast("请输入GPOP的num或value");
                    return;
                }
                int gpio = 0;
                try {
                    gpio = Integer.parseInt(etGpioNum.getText().toString());
                } catch (Exception e) {

                }
                if (gpio < 1) {
                    showToast("GPOP的num错误 num =" + gpio);
                    return;
                }
                boolean ret = SdkApi.getInstance().Hardware().setGpioOutput(0,
                        gpio, (etGpioValue.getText().toString().contains("1")) ? true : false);
                showToast("设置GPIO电平" + (ret ? "成功" : "失败"));
            }
            break;
        }
    }

    private void initView() {
        initInputGroupSelectView();
        initInputNumberSelectView();
        initOutputGroupSelectView();
        initOutputNumberSelectView();
        initOutputValueSelectView();
        Log.i(TAG, "initView: Build.MODEL "+Build.MODEL);
        if (!Build.MODEL.contains("950") && !Build.MODEL.contains("963") && !Build.MODEL.contains("982")) {
            llGGpio.setVisibility(View.GONE);
        }
    }

    private void initInputGroupSelectView() {
        List<String> list = new ArrayList<String>();
        list.add("GPIO0");
        list.add("GPIO1");
        list.add("GPIO2");
        list.add("GPIO3");
        list.add("GPIO4");
        list.add("GPIO5");
        list.add("GPIO6");
        list.add("GPIO7");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiInputGroupSelect.setAdapter(adapter);
        spiInputGroupSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                inputGroupSelectPosition = position;
                Log.i(TAG, "inputGroupSelectPosition = " + inputGroupSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiInputGroupSelect.setSelection(0);
    }

    private void initInputNumberSelectView() {
        List<String> list = new ArrayList<String>();
        list.add("PA0");
        list.add("PA1");
        list.add("PA2");
        list.add("PA3");
        list.add("PA4");
        list.add("PA5");
        list.add("PA6");
        list.add("PA7");
        list.add("PB0");
        list.add("PB1");
        list.add("PB2");
        list.add("PB3");
        list.add("PB4");
        list.add("PB5");
        list.add("PB6");
        list.add("PB7");
        list.add("PC0");
        list.add("PC1");
        list.add("PC2");
        list.add("PC3");
        list.add("PC4");
        list.add("PC5");
        list.add("PC6");
        list.add("PC7");
        list.add("PD0");
        list.add("PD1");
        list.add("PD2");
        list.add("PD3");
        list.add("PD4");
        list.add("PD5");
        list.add("PD6");
        list.add("PD7");


        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiInputNumberSelect.setAdapter(adapter);
        spiInputNumberSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                inputNumberSelectPosition = position;
                Log.i(TAG, "inputNumberSelectPosition = " + inputNumberSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiInputNumberSelect.setSelection(0);
    }

    private void initOutputValueSelectView() {
        List<String> list = new ArrayList<String>();
        list.add("高电平");
        list.add("低电平");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiOutputValueSelect.setAdapter(adapter);
        spiOutputValueSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                outputValueSelectPosition = position;
                Log.i(TAG, "outputValueSelectPosition = " + outputValueSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiOutputValueSelect.setSelection(0);
    }

    private void initOutputGroupSelectView() {
        List<String> list = new ArrayList<String>();
        list.add("GPIO0");
        list.add("GPIO1");
        list.add("GPIO2");
        list.add("GPIO3");
        list.add("GPIO4");
        list.add("GPIO5");
        list.add("GPIO6");
        list.add("GPIO7");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiOutputGroupSelect.setAdapter(adapter);
        spiOutputGroupSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                outputGroupSelectPosition = position;
                Log.i(TAG, "outputGroupSelectPosition = " + outputGroupSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiOutputGroupSelect.setSelection(0);
    }

    private void initOutputNumberSelectView() {
        List<String> list = new ArrayList<String>();
        list.add("PA0");
        list.add("PA1");
        list.add("PA2");
        list.add("PA3");
        list.add("PA4");
        list.add("PA5");
        list.add("PA6");
        list.add("PA7");
        list.add("PB0");
        list.add("PB1");
        list.add("PB2");
        list.add("PB3");
        list.add("PB4");
        list.add("PB5");
        list.add("PB6");
        list.add("PB7");
        list.add("PC0");
        list.add("PC1");
        list.add("PC2");
        list.add("PC3");
        list.add("PC4");
        list.add("PC5");
        list.add("PC6");
        list.add("PC7");
        list.add("PD0");
        list.add("PD1");
        list.add("PD2");
        list.add("PD3");
        list.add("PD4");
        list.add("PD5");
        list.add("PD6");
        list.add("PD7");


        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiOutputNumberSelect.setAdapter(adapter);
        spiOutputNumberSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                outputNumberSelectPosition = position;
                Log.i(TAG, "outputNumberSelectPosition = " + outputNumberSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiOutputNumberSelect.setSelection(0);
    }
}
