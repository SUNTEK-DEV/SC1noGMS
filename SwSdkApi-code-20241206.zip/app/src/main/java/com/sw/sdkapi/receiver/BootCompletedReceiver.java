package com.sw.sdkapi.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.sw.sdkapi.bean.AppData;
import com.sw.sdkapi.util.SystemPropertiesInvoke;

public class BootCompletedReceiver extends BroadcastReceiver {
    private final String TAG = BootCompletedReceiver.class.getSimpleName();

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = "";
        if(intent != null){
            action = intent.getAction();
        }

        Log.d(TAG, "onReceive api: 收到开机广播, name = " + action);

        AppData.addActionName(action);

        SystemPropertiesInvoke.set("sys.boot.complete.action", AppData.actionNameList.toString());
    }
}
