package com.sw.sdkapi;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import com.sw.sdkapi.R;
import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ResultCallback;
import com.sdkapi.common.ResultInfo;
import com.sw.sdkapi.util.ApiConvertUtil;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import androidx.annotation.Nullable;
import butterknife.BindView;
import butterknife.OnClick;

public class DisplayActivity extends BaseActivity {
    private final String TAG = DisplayActivity.class.getSimpleName();

    @BindView(R.id.text_lcd_density)
    TextView tvLcdDensity;
    @BindView(R.id.spi_screen_select)
    Spinner spiScreenSelect;
    @BindView(R.id.btn_screen_set_brightness)
    SeekBar sbScreenSetBrightness;
    @BindView(R.id.et_backlight_min)
    EditText etBacklightPwmMin;
    @BindView(R.id.et_backlight_max)
    EditText etBacklightPwmMax;
    @BindView(R.id.spi_resolution_select)
    Spinner spiResolutionSelect;
    @BindView(R.id.et_lcd_density)
    EditText etLcdDensity;

    private int screenSelectPosition = 0;
    private int currScreenBrightness = 50;

    private List<String> resolutionList = new LinkedList<>();
    private int resolutionSelectPosition = -1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }

    @OnClick({R.id.btn_back_display, R.id.btn_set_lcd_density,
            R.id.btn_screen_0, R.id.btn_screen_90, R.id.btn_screen_180, R.id.btn_screen_270,
            R.id.btn_screen_get, R.id.btn_screen_on, R.id.btn_screen_off, R.id.btn_screen_get_status,
            R.id.btn_screen_get_brightness, R.id.btn_screen_set_backlight_positive, R.id.btn_screen_set_backlight_negative,
            R.id.btn_screen_get_backlight_inverse, R.id.btn_screen_set_backlight_pwm, R.id.btn_screen_get_backlight_pwm,
            R.id.btn_screen_get_resolution, R.id.btn_screen_set_resolution, R.id.btn_screen_set_lvds_mode_vesa,
            R.id.btn_screen_set_lvds_mode_jeida, R.id.btn_screen_get_lvds_mode, R.id.btn_screen_set_lvds_swap,
            R.id.btn_screen_set_lvds_swap_no, R.id.btn_screen_get_lvds_swap, R.id.btn_screen_set_lvds_channel_singal,
            R.id.btn_screen_set_lvds_channel_dual, R.id.btn_screen_get_lvds_channel})
    public void onViewClicked(View view) {
        int viewId = view.getId();
        switch (viewId) {
            case R.id.btn_back_display:{
                finish();
            }
            break;
            case R.id.btn_set_lcd_density:{
                String density = etLcdDensity.getText().toString();
                if(TextUtils.isEmpty(density)){
                    showToast("待设置密度数据为空");
                    return;
                }

                Log.i(TAG, "set lcd density = " + density);
                try {
                    SdkApi.getInstance().DeviceInfo().setLcdDensity(Integer.parseInt(density.trim()));
                    showToast("屏幕密度设置已执行");
                }catch (Exception e){
                    showToast("屏幕密度设置失败");
                }
            }
            break;
            case R.id.btn_screen_0:
            case R.id.btn_screen_90:
            case R.id.btn_screen_180:
            case R.id.btn_screen_270:{
                boolean ret = false;
                if(viewId == R.id.btn_screen_0){
                    Log.i(TAG, "screen select = " + screenSelectPosition + "; ori = 0");
                    ret = SdkApi.getInstance().Display().setScreenRotate(screenSelectPosition, 0);
                }else if(viewId == R.id.btn_screen_90){
                    Log.i(TAG, "screen select = " + screenSelectPosition + "; ori = 90");
                    ret = SdkApi.getInstance().Display().setScreenRotate(screenSelectPosition, 90);
                }else if(viewId == R.id.btn_screen_180){
                    Log.i(TAG, "screen select = " + screenSelectPosition + "; ori = 180");
                    ret = SdkApi.getInstance().Display().setScreenRotate(screenSelectPosition, 180);
                }else if(viewId == R.id.btn_screen_270){
                    Log.i(TAG, "screen select = " + screenSelectPosition + "; ori = 270");
                    ret = SdkApi.getInstance().Display().setScreenRotate(screenSelectPosition, 270);
                }

                showToast("旋转屏幕" + (ret ? "成功" : "失败"));

                if(ret){
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            SdkApi.getInstance().SystemCtrl().deviceReboot();
                        }
                    }, 2000);
                }
            }
                break;
            case R.id.btn_screen_get:{
                SdkApi.getInstance().Display().getScreenRotate(screenSelectPosition, new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToast("当前屏幕方向：" + str);
                    }
                });
            }
            break;
            case R.id.btn_screen_on:{
                boolean ret = SdkApi.getInstance().Display().setScreenOnoff(screenSelectPosition, true);
                showToast("打开屏幕" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_off:{
                boolean ret = SdkApi.getInstance().Display().setScreenOnoff(screenSelectPosition, false);
                showToast("关闭屏幕" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_get_status:{
                SdkApi.getInstance().Display().getScreenOnoff(screenSelectPosition, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToast("当前屏幕状态：" + str);
                    }
                });
            }
            break;
            case R.id.btn_screen_get_brightness:{
                SdkApi.getInstance().Display().getBrightness(screenSelectPosition, new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if(val == null){
                            return;
                        }

                        if("success".equals(val.getStatus())){
                            final int brightness = val.getVal();
                            postUiRunnable(new Runnable() {
                                @Override
                                public void run() {
                                    showToast("当前屏幕亮度: " + brightness);
                                    sbScreenSetBrightness.setProgress(brightness);
                                }
                            }, 100);
                        }else{
                            showToast("当前屏幕亮度获取失败");
                        }
                    }
                });
            }
            break;
            case R.id.btn_screen_set_backlight_positive:{
                boolean ret = SdkApi.getInstance().Display().setBacklightInverse(screenSelectPosition, true);
                showToast("设置背光正向" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_set_backlight_negative:{
                boolean ret = SdkApi.getInstance().Display().setBacklightInverse(screenSelectPosition, false);
                showToast("设置背光反向" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_get_backlight_inverse:{
                SdkApi.getInstance().Display().getBacklightInverse(screenSelectPosition, new ResultCallback<ResultInfo<Boolean>>() {
                    @Override
                    public void onMsg(ResultInfo<Boolean> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToast("当前屏幕背光状态：" + str);
                    }
                });
            }
            break;
            case R.id.btn_screen_set_backlight_pwm:{
                String strMin = etBacklightPwmMin.getText().toString();
                String strMax = etBacklightPwmMax.getText().toString();

                if(TextUtils.isEmpty(strMin) || TextUtils.isEmpty(strMax)){
                    showToast("背光最大值或者最小值为空");
                    return;
                }

                try {
                    boolean ret = SdkApi.getInstance().Display().setBacklightPWM(screenSelectPosition, Integer.parseInt(strMin), Integer.parseInt(strMax));
                    showToast("设置背光PWM" + (ret ? "成功" : "失败"));
                }catch (Exception e){
                    showToast("设置背光PWM失败");
                }
            }
            break;
            case R.id.btn_screen_get_backlight_pwm:{
                SdkApi.getInstance().Display().getBacklightPWM(screenSelectPosition, new ResultCallback<ResultInfo<String>>() {
                    @Override
                    public void onMsg(ResultInfo<String> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToast("当前屏幕背光PWM：" + str);
                    }
                });
            }
            break;
            case R.id.btn_screen_get_resolution:{
                SdkApi.getInstance().Display().getResolution(screenSelectPosition, new ResultCallback<ResultInfo<String>>() {
                    @Override
                    public void onMsg(ResultInfo<String> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        showToast("当前屏幕分辨率：" + str);
                    }
                });
            }
            break;
            case R.id.btn_screen_set_resolution:{
                String str = "";
                if((resolutionList == null) || (resolutionList.size() <= 0)){
                    showToast("当前屏幕分辨率列表为空");
                    return;
                }

                if((resolutionSelectPosition < 0) || (resolutionSelectPosition >= resolutionList.size())){
                    showToast("当前选择的分辨率索引不对");
                    return;
                }

                str = resolutionList.get(resolutionSelectPosition);
                if("no resolution".equals(str) || ApiConvertUtil.isErrorResult(str)){
                    showToast("无有效分辨率");
                    return;
                }

                if (!TextUtils.isEmpty(str) && (str.endsWith("@50") || str.endsWith("@60"))) {
                    str = str.substring(0, str.length() - 3);
                }

                boolean ret = SdkApi.getInstance().Display().setResolution(screenSelectPosition, str);
                showToast("设置屏幕分辨率" + (ret ? "成功" : "失败"));
                if(ret){
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            SdkApi.getInstance().SystemCtrl().deviceReboot();
                        }
                    }, 2000);
                }
            }
            break;
            case R.id.btn_screen_set_lvds_mode_vesa:{
                boolean ret = SdkApi.getInstance().Display().setLvdsMode(screenSelectPosition, 0);
                showToast("设置屏幕模式[VESA]" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_set_lvds_mode_jeida:{
                boolean ret = SdkApi.getInstance().Display().setLvdsMode(screenSelectPosition, 1);
                showToast("设置屏幕模式[JEIDA]" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_get_lvds_mode:{
                SdkApi.getInstance().Display().getLvdsMode(screenSelectPosition, new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        if("0".equals(str)){
                            showToast("当前屏幕模式：VESA");
                        }else if("1".equals(str)){
                            showToast("当前屏幕模式：JEIDA");
                        }else{
                            showToast("当前屏幕模式：" + str);
                        }
                    }
                });
            }
            break;
            case R.id.btn_screen_set_lvds_swap:{
                boolean ret = SdkApi.getInstance().Display().setLvdsSwap(screenSelectPosition, 1);
                showToast("设置屏幕[SWAP]" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_set_lvds_swap_no:{
                boolean ret = SdkApi.getInstance().Display().setLvdsSwap(screenSelectPosition, 0);
                showToast("设置屏幕[NO SWAP]" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_get_lvds_swap:{
                SdkApi.getInstance().Display().getLvdsSwap(screenSelectPosition, new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        if("0".equals(str)){
                            showToast("当前屏幕模式：NO SWAP");
                        }else if("1".equals(str)){
                            showToast("当前屏幕模式：SWAP");
                        }else{
                            showToast("当前屏幕模式：" + str);
                        }
                    }
                });
            }
            break;
            case R.id.btn_screen_set_lvds_channel_singal:{
                boolean ret = SdkApi.getInstance().Display().setLvdsChannel(screenSelectPosition, 0);
                showToast("设置屏幕单通道" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_set_lvds_channel_dual:{
                boolean ret = SdkApi.getInstance().Display().setLvdsChannel(screenSelectPosition, 1);
                showToast("设置屏幕双通道" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_screen_get_lvds_channel:{
                SdkApi.getInstance().Display().getLvdsChannel(screenSelectPosition, new ResultCallback<ResultInfo<Integer>>() {
                    @Override
                    public void onMsg(ResultInfo<Integer> val) {
                        if(val == null){
                            return;
                        }

                        String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                        if("0".equals(str)){
                            showToast("当前屏幕: 单通道");
                        }else if("1".equals(str)){
                            showToast("当前屏幕: 双通道");
                        }else{
                            showToast("当前屏幕模式：" + str);
                        }
                    }
                });
            }
            break;
        }
    }

    private void initView(){
        tvLcdDensity.setText("屏幕密度：" + SdkApi.getInstance().DeviceInfo().getLcdDensity());

        initScreenSelectView();

        sbScreenSetBrightness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                SdkApi.getInstance().Display().setBrightness(screenSelectPosition, progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        initResolutionSelectView();
    }

    private void initScreenSelectView(){
        List<String> list = new ArrayList<String>();
        list.add("ALL");
        list.add("LVDS");
        list.add("LVDS2");
        list.add("eDP");
        list.add("MIPI");
        list.add("VB1");
        list.add("HDMI");
        list.add("DP");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiScreenSelect.setAdapter(adapter);
        spiScreenSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                screenSelectPosition = position;
                Log.i(TAG, "screenSelectPosition = " + screenSelectPosition);

                initResolutionSelectView();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiScreenSelect.setSelection(0);
    }

    private void initResolutionSelectView(){
        if(resolutionList != null){
            resolutionList.clear();
        }

        String str = SdkApi.getInstance().Display().getSupportedResolutionsList(screenSelectPosition);
        Log.i(TAG, "initResolutionSelectView: " + str);
        if(TextUtils.isEmpty(str) || "none".equals(str)){
            resolutionList.add("no resolution");
        }else{
            String[] res = str.split(",");
            if ((res == null) || (res.length <= 0)) {
                resolutionList.add("no resolution");
            }else{
                for (int i = 0; i < res.length; i++) {
                    resolutionList.add(res[i] + "Hz");
                }
            }
        }

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, resolutionList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiResolutionSelect.setAdapter(adapter);
        spiResolutionSelect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                resolutionSelectPosition = position;
                Log.i(TAG, "resolutionSelectPosition = " + resolutionSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
