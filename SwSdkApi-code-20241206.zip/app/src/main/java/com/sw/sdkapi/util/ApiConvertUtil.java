package com.sw.sdkapi.util;

import java.text.SimpleDateFormat;

public class ApiConvertUtil {
    public static final String FailText = "失败";
    public static final String NotSupportText = "固件不支持该接口";

    public static boolean isErrorResult(String str){
        if(FailText.equals(str) || NotSupportText.equals(str)){
            return true;
        }

        return false;
    }

    public static <T> String getResultStr(T val, String status){
        String str = "null";

        switch (status) {
            case "success":
                str = val + "";
                break;
            case "fail":
                str = FailText;
                break;
            case "not-support":
                str = NotSupportText;
                break;
        }

        return str;
    }

    public static boolean isMatchPowerTime(String str){
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        try{
            sdf.parse(str);
        }catch (Exception e){
            return false;
        }

        return true;
    }
}
