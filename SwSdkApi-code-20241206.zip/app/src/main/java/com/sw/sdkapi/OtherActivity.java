package com.sw.sdkapi;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import com.sw.sdkapi.R;
import com.google.gson.Gson;
import com.sdkapi.api.SdkApi;
import com.sdkapi.sdkapiservice.ISdkCommonListener;
import com.sw.sdkapi.bean.AppData;
import com.sw.sdkapi.bean.LogoInfo;
import com.sw.sdkapi.util.FileUtil;
import com.sw.sdkapi.util.SystemPropertiesInvoke;

import androidx.annotation.Nullable;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class OtherActivity extends BaseActivity {
    private final String TAG = OtherActivity.class.getSimpleName();

    @BindView(R.id.et_adb_cmd)
    EditText etAdbCmd;
    @BindView(R.id.tv_emmc_left_time)
    TextView tvEmmcLeftTime;
    @BindView(R.id.tv_boot_receiver_action)
    TextView tvBootReceiverAction;
    @BindView(R.id.et_contrast)
    EditText etContrast;
    @BindView(R.id.et_saturation)
    EditText etSaturation;
    @BindView(R.id.et_hue)
    EditText etHue;
    @BindView(R.id.et_signal_brightness)
    EditText etSignalBrightness;
    public final int AppId = android.os.Process.myPid();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();

        SdkApi.getInstance().CommonEvent().registerCommonListener(AppId, commonListener);
    }

    @Override
    protected void onPause() {
        super.onPause();

        SdkApi.getInstance().CommonEvent().unregisterCommonListener(AppId, commonListener);

        finish();
    }

    @OnClick({R.id.btn_back_other,
            R.id.btn_get_sim_iccid, R.id.btn_get_4g_imei, R.id.btn_get_emmc_left_time,
            R.id.btn_exec_adb_cmd, R.id.btn_get_contrast, R.id.btn_get_saturation, R.id.btn_get_hue,
            R.id.btn_set_contrast, R.id.btn_set_saturation, R.id.btn_set_hue, R.id.btn_set_signal_brightness, R.id.btn_get_signal_brightness,
            R.id.btn_check_usb, R.id.btn_set_logo, R.id.btn_set_ota, R.id.btn_get_scale_type})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_other: {
                finish();
            }
            break;
            case R.id.btn_get_sim_iccid: {
                String iccid = SdkApi.getInstance().Other().getSimICCID();
                showToast("SIM卡 ICCID = " + iccid);
            }
            break;
            case R.id.btn_get_4g_imei: {
                String imei = SdkApi.getInstance().Other().getModemIMEI();
                showToast("移动模块 IMEI = " + imei);
            }
            break;
            case R.id.btn_get_emmc_left_time: {
                String leftTime = SdkApi.getInstance().Other().getEmmcLeftTime();
                tvEmmcLeftTime.setText(leftTime);
                showToast("EMMC 寿命 = " + leftTime);
            }
            break;
            case R.id.btn_exec_adb_cmd: {
                final String data = etAdbCmd.getText().toString();
                if (TextUtils.isEmpty(data)) {
                    showToast("命令不能为空");
                    return;
                }

                SdkApi.getInstance().Other().execShellCommand(data);
                showToastShort("命令已执行");
            }
            break;
            case R.id.btn_set_contrast: {
                String data = etContrast.getText().toString();
                try {
                    int value = Integer.parseInt(data);
                    if ((value < 0) || (value > 100)) {
                        showToastShort("数据范围是0-100");
                        return;
                    }

                    int[] dataArray = {value};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9082, "", dataArray, 1);
                } catch (Exception e) {
                    showToastShort("数据格式不对");
                }
            }
            break;
            case R.id.btn_get_contrast: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9083, "", dataArray, 1);
            }
            break;
            case R.id.btn_set_saturation: {
                String data = etSaturation.getText().toString();
                try {
                    int value = Integer.parseInt(data);
                    if ((value < 0) || (value > 100)) {
                        showToastShort("数据范围是0-100");
                        return;
                    }

                    int[] dataArray = {value};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9080, "", dataArray, 1);
                } catch (Exception e) {
                    showToastShort("数据格式不对");
                }
            }
            break;
            case R.id.btn_get_saturation: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9081, "", dataArray, 1);
            }
            break;
            case R.id.btn_set_hue: {
                String data = etHue.getText().toString();
                try {
                    int value = Integer.parseInt(data);
                    if ((value < 0) || (value > 100)) {
                        showToastShort("数据范围是0-100");
                        return;
                    }

                    int[] dataArray = {value};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9084, "", dataArray, 1);
                } catch (Exception e) {
                    showToastShort("数据格式不对");
                }
            }
            break;
            case R.id.btn_get_hue: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9085, "", dataArray, 1);
            }
            break;
            case R.id.btn_set_signal_brightness: {
                String data = etSignalBrightness.getText().toString();
                try {
                    int value = Integer.parseInt(data);
                    if ((value < 0) || (value > 100)) {
                        showToastShort("数据范围是0-100");
                        return;
                    }

                    int[] dataArray = {value};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9086, "", dataArray, 1);
                } catch (Exception e) {
                    showToastShort("数据格式不对");
                }
            }
            break;
            case R.id.btn_get_signal_brightness: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9087, "", dataArray, 1);
            }
            break;
            case R.id.btn_check_usb: {
                initUSB();

                if ((horLogoInfo == null) && (verLogoInfo == null)) {
                    showToastShort("没有找到动画文件");
                } else {
                    showToastShort("找到了动画文件");
                }
            }
            break;
            case R.id.btn_set_logo: {
                if (horLogoInfo != null) {
                    Gson gson = new Gson();

                    String data = gson.toJson(horLogoInfo);
                    int[] dataArray = {1};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9090, data, dataArray, 1);
                }

                if (verLogoInfo != null) {
                    Gson gson = new Gson();

                    String data = gson.toJson(verLogoInfo);
                    int[] dataArray = {1};
                    SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9090, data, dataArray, 1);
                }
            }
            break;
            case R.id.btn_set_ota: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9091, "/sdcard/update.zip", dataArray, 1);
//                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9091, "/data/media/0/update.zip", dataArray, 1);
            }
            break;
            case R.id.btn_get_scale_type: {
                int[] dataArray = {1};
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x9091, "", dataArray, 1);
            }
            break;
        }
    }

    private void initView() {
        Log.i(TAG, "init data = " + AppData.actionNameList.toString());

        String str = SystemPropertiesInvoke.get("sys.boot.complete.action", "未收到任何广播");

        String data = "开机广播接收action: " + "\n";

        data += str;
//        if(AppData.actionNameList.size() <= 0){
//            data += "未收到任何广播";
//            data += "\n";
//        }else{
//            for (int i = 0; i < AppData.actionNameList.size(); i++){
//                data += AppData.actionNameList.get(i);
//                data += "\n";
//            }
//        }

        tvBootReceiverAction.setText(data);
    }

    private ISdkCommonListener commonListener = new ISdkCommonListener.Stub() {

        @Override
        public IBinder asBinder() {
            return super.asBinder();
        }

        @Override
        public void CommonListenerNotify(int actionId, String sVal, int[] iArray, int intArrayLen) throws RemoteException {
            int progress = intArrayLen;
            Log.i(TAG, "notify actionId = " + actionId + "; AppId = " + AppId + "; sVal = " + sVal + "; progress = " + progress);
            if (actionId == 0x9081) {  //saturation
                try {
                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("当前饱和度 = " + data);
                        }
                    }, 0);
                } catch (Exception e) {
                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("饱和度获取失败");
                        }
                    }, 0);
                }
            } else if (actionId == 0x9083) {  //contrast
                try {
                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("当前对比度 = " + data);
                        }
                    }, 0);
                } catch (Exception e) {
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("对比度获取失败");
                        }
                    }, 0);
                }
            } else if (actionId == 0x9085) {  //hue
                try {
                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("当前灰阶 = " + data);
                        }
                    }, 0);
                } catch (Exception e) {
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("灰阶获取失败");
                        }
                    }, 0);
                }
            }
            else if (actionId == 0x9087) {  //屏幕信号亮度
                try {
                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("当前屏幕信号亮度 = " + data);
                        }
                    }, 0);
                } catch (Exception e) {
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("获取屏幕信号亮度失败");
                        }
                    }, 0);
                }
            }else if (actionId == 0x9090) {
                if (intArrayLen == 1) {
                    if (iArray[0] == 0x00) {
                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                showToast("动画设置成功，请重启设备");
                            }
                        }, 0);
                    } else {
                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                showToast("动画设置失败");
                            }
                        }, 0);
                    }
                }
            } else if (actionId == 0x9091) {
                if (intArrayLen == 1) {
                    if (iArray[0] == 0x00) {
                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                showToast("开始OTA升级");
                            }
                        }, 0);
                    } else {
                        postUiRunnable(new Runnable() {
                            @Override
                            public void run() {
                                showToast("OTA升级失败");
                            }
                        }, 0);
                    }
                }
            }
        }
    };

    private LogoInfo horLogoInfo = null;
    private LogoInfo verLogoInfo = null;

    /**
     * 初始化USB路径
     */
    private void initUSB() {
        horLogoInfo = null;
        verLogoInfo = null;

        List<String> usbPath = FileUtil.getUSBPaths(getApplication());
        for (int i = 0; i < usbPath.size(); i++) {
            if (new File(usbPath.get(i), "bootanimation.zip").exists()) {
                horLogoInfo = new LogoInfo();
                horLogoInfo.setType(0);
                horLogoInfo.setLogoFileType(1);
                horLogoInfo.setOrientation("horizontal");
                horLogoInfo.setLogoFilePath(usbPath.get(i) + "/" + "bootanimation.zip");
            } else if (new File(usbPath.get(i), "bootanimation.mp4").exists()) {
                horLogoInfo = new LogoInfo();
                horLogoInfo.setType(0);
                horLogoInfo.setLogoFileType(2);
                horLogoInfo.setOrientation("horizontal");
                horLogoInfo.setLogoFilePath(usbPath.get(i) + "/" + "bootanimation.mp4");
            } else if (new File(usbPath.get(i), "bootanimation_v.zip").exists()) {
                verLogoInfo = new LogoInfo();
                verLogoInfo.setType(0);
                verLogoInfo.setLogoFileType(1);
                verLogoInfo.setOrientation("vertical");
                verLogoInfo.setLogoFilePath(usbPath.get(i) + "/" + "bootanimation_v.zip");
            } else if (new File(usbPath.get(i), "bootanimation_v.mp4").exists()) {
                verLogoInfo = new LogoInfo();
                verLogoInfo.setType(0);
                verLogoInfo.setLogoFileType(2);
                verLogoInfo.setOrientation("vertical");
                verLogoInfo.setLogoFilePath(usbPath.get(i) + "/" + "bootanimation_v.mp4");
            }
        }
    }
}
