package com.sw.sdkapi.view.activity.hardware;

import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.sdkapi.api.SdkApi;
import com.sdkapi.sdkapiservice.ISdkCommonListener;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class WiegandActivity extends BaseActivity {
    private final String TAG = WiegandActivity.class.getSimpleName();

    private final int AppId = android.os.Process.myPid();

    @BindView(R.id.tv_hardware_wiegand_receive)
    TextView tvReceiveData;
    @BindView(R.id.et_hardware_wiegand_send_data)
    EditText etSendData;
    @BindView(R.id.spi_wiegang_xieyi)
    Spinner spiXieyi;  //韦根协议

    private int xieyiSelectPosition;
    private final List<String> xieyiList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_wiegand);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();

        SdkApi.getInstance().CommonEvent().registerCommonListener(AppId, commonListener);
    }

    @Override
    protected void onPause() {
        super.onPause();

        isStop = true;
        SdkApi.getInstance().CommonEvent().unregisterCommonListener(AppId, commonListener);

        finish();
    }

    @OnClick({R.id.btn_back_hardware_wiegand,
            R.id.btn_hardware_wiegand_config, R.id.btn_hardware_wiegand_send, R.id.btn_hardware_wiegand_start,
            R.id.btn_hardware_wiegand_stop})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_wiegand: {
                finish();
            }
            break;
            case R.id.btn_hardware_wiegand_config: {
                String data = xieyiList.get(xieyiSelectPosition);

                int[] dataAr = new int[1];
                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x010004, data, dataAr, 1);
            }
            break;
            case R.id.btn_hardware_wiegand_send: {
                String str = etSendData.getText().toString();
                if(TextUtils.isEmpty(str)){
                    showToastShort("待发送数据不可为空");
                    return;
                }

                int[] data = new int[str.getBytes().length];
                for(int i = 0; i < data.length; i++){
                    data[i] = str.getBytes()[i] & 0xFF;
                }

                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x010005, null, data, data.length);
            }
            break;
            case R.id.btn_hardware_wiegand_start: {
                if(isStop){
                    return;
                }

                isStop = false;
                new Thread(runnable).start();
                showToast("开始接收数据");
            }
            break;
            case R.id.btn_hardware_wiegand_stop: {
                isStop = true;
                showToast("停止接收数据");
            }
            break;
        }
    }

    private void initView(){
        initXieyiView();
    }

    private void initXieyiView(){
        xieyiSelectPosition = 0;

        xieyiList.add("26");
        xieyiList.add("32");
        xieyiList.add("34");
        xieyiList.add("36");
        xieyiList.add("37");
        xieyiList.add("58");

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, xieyiList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spiXieyi.setAdapter(adapter);
        spiXieyi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                xieyiSelectPosition = position;
                Log.i(TAG, "xieyiSelectPosition = " + xieyiSelectPosition);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spiXieyi.setSelection(0);
    }

    private boolean isStop = false;
    private Runnable runnable = new Runnable() {

        @Override
        public void run() {
            int[] dataArray = new int[1];
            dataArray[0] = 1;

            while (!isStop){

                SdkApi.getInstance().CommonEvent().setCommonEvent(AppId, 0x010006, null, dataArray, 1);

                int timeout = 0;
                while (!isStop && (timeout++ < 10)){
                    try {
                        Thread.sleep(50);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    };

    private ISdkCommonListener commonListener = new ISdkCommonListener.Stub() {

        @Override
        public IBinder asBinder() {
            return super.asBinder();
        }

        @Override
        public void CommonListenerNotify(int actionId, final String sVal, int[] iArray, int intArrayLen) throws RemoteException {
            int progress = intArrayLen;
            Log.i(TAG, "notify actionId = " + actionId + "; AppId = " + AppId + "; sVal = " + sVal + "; progress = " + progress);

            if (actionId == 0x010004){ //config
                if(iArray[0] == 0){
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("配置成功");
                        }
                    }, 0);
                }
            } else if (actionId == 0x010006) {  //收到韦根数据
                if(iArray[0] != 0){
                    return;
                }

                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        tvReceiveData.setText(sVal);
                        int offset = getTextViewContentHeight(tvReceiveData);//调用getTextViewContentHeight
                        if (offset > tvReceiveData.getHeight()) {
                            tvReceiveData.scrollTo(0, offset - tvReceiveData.getHeight());
                        }
                    }
                }, 0);
            }
        }
    };

    /**
     * 获取TextView中内容的高度
     * @param textView
     * @return
     */
    public int getTextViewContentHeight(TextView textView) {
        Layout layout = textView.getLayout();
        int desired = layout.getLineTop(textView.getLineCount());
        int padding = textView.getCompoundPaddingTop() + textView.getCompoundPaddingBottom();
        return desired + padding;
    }
}
