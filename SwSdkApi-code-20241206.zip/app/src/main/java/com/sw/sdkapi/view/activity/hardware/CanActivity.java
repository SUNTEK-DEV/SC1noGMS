package com.sw.sdkapi.view.activity.hardware;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import androidx.annotation.Nullable;
import butterknife.OnClick;

public class CanActivity extends BaseActivity {
    private final String TAG = CanActivity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hardware_can);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @OnClick({R.id.btn_back_hardware_can_main,
            R.id.btn_hardware_can_func, R.id.btn_hardware_can_age})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_hardware_can_main: {
                finish();
            }
            break;
            case R.id.btn_hardware_can_func:{
                startActivity(new Intent(this, CanFuncActivity.class));
            }
            break;
            case R.id.btn_hardware_can_age:{
                startActivity(new Intent(this, CanAgeActivity.class));
            }
            break;
        }
    }

}
