package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothDevice;

public class BluetoothDeviceInfo {
    public BluetoothDevice device;
    public int rssi;
}
