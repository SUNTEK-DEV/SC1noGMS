package com.sw.sdkapi;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.sw.sdkapi.R;
import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.util.ApiConvertUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import androidx.annotation.Nullable;

import butterknife.BindView;
import butterknife.OnClick;

public class TimerSwitchActivity extends BaseActivity {
    private final String TAG = TimerSwitchActivity.class.getSimpleName();
    private static final String YMDHMFormat = "yyyy-MM-dd HH:mm";
    @BindView(R.id.et_power_on_time)
    EditText etPowerOnTime;
    @BindView(R.id.et_power_off_time)
    EditText etPowerOffTime;
    @BindView(R.id.tv_system_time)
    TextView tvSystemTime;
    @BindView(R.id.edit_ymd_time_on)
    EditText etPowerOnTimeYmd;
    @BindView(R.id.edit_ymd_time_off)
    EditText etPowerOffTimeYmd;
    @BindView(R.id.switch_timer_set_ymd_type)
    Switch switchSetYmdType;
    private boolean isStop = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timerswitch);

        updateSystemTime();
        switchSetYmdType.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                boolean flag = SdkApi.getInstance().TimerSwitch().setTimerType(b);
                Toast.makeText(TimerSwitchActivity.this, "设置开关机类型：" + (flag ? "成功" : "失败"), Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked: set_ymd_type flag = " + flag);
            }
        });
        initCheckBox();
        initEditText();
    }

    private void initEditText() {
        String strTimerOnTime = SdkApi.getInstance().TimerSwitch().getTimerOnTime();
        if (!TextUtils.isEmpty(strTimerOnTime)) {
            etPowerOnTime.setText(strTimerOnTime);
        }
        String strTimerOffTime = SdkApi.getInstance().TimerSwitch().getTimerOffTime();
        if (!TextUtils.isEmpty(strTimerOffTime)) {
            etPowerOffTime.setText(strTimerOffTime);
        }
    }

    public static boolean isValidDate(String str, String pattern) {
        boolean convertSuccess = true;
        // 指定日期格式为四位年/两位月份/两位日期，注意yyyy/MM/dd区分大小写；
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            // 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
            format.setLenient(false);
            format.parse(str);
        } catch (ParseException e) {
            convertSuccess = false;
        }
        return convertSuccess;
    }

    private void initCheckBox() {
        boolean flag = SdkApi.getInstance().TimerSwitch().getTimerType();
        Log.i(TAG, "initCheckBox:getTimerType: " + flag);
        switchSetYmdType.setChecked(flag);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        isStop = true;

        finish();
    }

    @OnClick({R.id.btn_back_timerswitch,
            R.id.btn_timer_on, R.id.btn_timer_off, R.id.btn_timer_get_status,
            R.id.btn_timer_set_mode_shadow, R.id.btn_timer_set_mode_deep, R.id.btn_timer_get_mode,
            R.id.btn_timer_set_power_on_time, R.id.btn_timer_clear_power_on_time, R.id.btn_timer_get_power_on_time,
            R.id.btn_timer_set_power_off_time, R.id.btn_timer_clear_power_off_time, R.id.btn_timer_get_power_off_time,
            R.id.btn_timer_set_ymd_on, R.id.btn_timer_set_ymd_off, R.id.btn_timer_get_ymd_on, R.id.btn_timer_get_ymd_off, R.id.btn_timer_get_ymd_type})
    public void onViewClicked(View view) {
        int viewId = view.getId();
        switch (viewId) {
            case R.id.btn_back_timerswitch: {
                finish();
            }
            break;
            case R.id.btn_timer_set_ymd_on: {
                final String str = etPowerOnTimeYmd.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToastShort("开机时间为空");
                    return;
                }

                if (!isValidDate(str, YMDHMFormat)) {
                    showToastShort("开机时间格式不对，正确的格式是" + YMDHMFormat);
                    return;
                }
                boolean flag = SdkApi.getInstance().TimerSwitch().setTimerOnYmdTime(str);
                Toast.makeText(this, "设置开机时间" + (flag ? "成功" : "失败"), Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked: set_ymd_on " + flag);
            }
            break;
            case R.id.btn_timer_get_ymd_on: {
                String temp = SdkApi.getInstance().TimerSwitch().getTimerOnYmdTime();
                Toast.makeText(this, "开机时间：" + temp, Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked:getTimerOnYmdTime: " + temp);
            }
            break;
            case R.id.btn_timer_set_ymd_off: {
                final String str = etPowerOffTimeYmd.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToastShort("关机时间为空");
                    return;
                }

                if (!isValidDate(str, YMDHMFormat)) {
                    showToastShort("关机机时间格式不对，正确的格式是" + YMDHMFormat);
                    return;
                }
                boolean flag = SdkApi.getInstance().TimerSwitch().setTimerOffYmdTime(str);//"yyyy-MM-dd HH:mm"
                Toast.makeText(this, "设置关机时间" + (flag ? "成功" : "失败"), Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked: set_ymd_off " + flag);
            }
            break;
            case R.id.btn_timer_get_ymd_off: {
                String temp = SdkApi.getInstance().TimerSwitch().getTimerOffYmdTime();
                Toast.makeText(this, "关机时间：" + temp, Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked:btn_timer_get_ymd_off: " + temp);
            }
            break;

//            case R.id.btn_timer_set_ymd_type: {
//                boolean flag = SdkApi.getInstance().TimerSwitch().setTimerType(false);
//                Log.i(TAG, "onViewClicked: set_ymd_type flag = " + flag);
//            }
//            break;
            case R.id.btn_timer_get_ymd_type: {
                boolean flag = SdkApi.getInstance().TimerSwitch().getTimerType();
                Toast.makeText(this, "当前开关机类型：" + (flag ? "定时年月日" : "按星期开关机"), Toast.LENGTH_LONG).show();
                Log.i(TAG, "onViewClicked:getTimerType: " + flag);
            }
            break;

            case R.id.btn_timer_on: {
                SdkApi.getInstance().TimerSwitch().setTimerSwitchOnoff(true);
                showToastShort("定时开关机业务开启设置");
            }
            break;

            case R.id.btn_timer_off: {
                SdkApi.getInstance().TimerSwitch().setTimerSwitchOnoff(false);
                showToastShort("定时开关机业务关闭");
            }
            break;
            case R.id.btn_timer_get_status: {
                boolean ret = SdkApi.getInstance().TimerSwitch().getTimerSwitchOnoff();
                showToastShort("定时开关机业务" + (ret ? "已开启" : "已关闭"));
            }
            break;
            case R.id.btn_timer_set_mode_shadow: {
                SdkApi.getInstance().TimerSwitch().setTimerStandbyMode(false);
            }
            break;
            case R.id.btn_timer_set_mode_deep: {
                SdkApi.getInstance().TimerSwitch().setTimerStandbyMode(true);
            }
            break;
            case R.id.btn_timer_get_mode: {
                boolean ret = SdkApi.getInstance().TimerSwitch().getTimerStandbyMode();
                showToastShort("当前是" + (ret ? "低功耗模式" : "假关机模式"));
            }
            break;
            case R.id.btn_timer_set_power_on_time: {
                final String str = etPowerOnTime.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToastShort("开机时间为空");
                    return;
                }

                if (!ApiConvertUtil.isMatchPowerTime(str)) {
                    showToastShort("开机时间格式不对，正确的格式是HH:mm");
                    return;
                }

                boolean ret = SdkApi.getInstance().TimerSwitch().setTimerOnTime(str);
                showToastShort("设置开机时间" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_timer_clear_power_on_time: {
                SdkApi.getInstance().TimerSwitch().clearTimerOnTime();
            }
            break;
            case R.id.btn_timer_get_power_on_time: {
                String str = SdkApi.getInstance().TimerSwitch().getTimerOnTime();
                showToastShort("开机时间: " + str);
            }
            break;
            case R.id.btn_timer_set_power_off_time: {
                final String str = etPowerOffTime.getText().toString();
                if (TextUtils.isEmpty(str)) {
                    showToastShort("关机时间为空");
                    return;
                }

                if (!ApiConvertUtil.isMatchPowerTime(str)) {
                    showToastShort("关机时间格式不对，正确的格式是HH:mm");
                    return;
                }

                boolean ret = SdkApi.getInstance().TimerSwitch().setTimerOffTime(str);
                showToastShort("设置关机时间" + (ret ? "成功" : "失败"));
            }
            break;
            case R.id.btn_timer_clear_power_off_time: {
                SdkApi.getInstance().TimerSwitch().clearTimerOffTime();
            }
            break;
            case R.id.btn_timer_get_power_off_time: {
                String str = SdkApi.getInstance().TimerSwitch().getTimerOffTime();
                showToastShort("关机时间: " + str);
            }
            break;
        }
    }

    private void updateSystemTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

        tvSystemTime.setText("当前系统时间：" + sdf.format(System.currentTimeMillis()));

        postUiRunnable(new Runnable() {
            @Override
            public void run() {
                if (isStop) {
                    return;
                }

                updateSystemTime();
            }
        }, 1000);
    }
}
