package com.sw.sdkapi;

import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.sdkapi.api.SdkApi;
import com.sw.sdkapi.R;
import java.io.File;
import java.text.DecimalFormat;

import androidx.annotation.Nullable;

import butterknife.BindView;
import butterknife.OnClick;

public class BaseInfoActivity extends BaseActivity {
    private final String TAG = BaseInfoActivity.class.getSimpleName();

    @BindView(R.id.text_chip_name)
    TextView tvChipName;
    @BindView(R.id.text_ddr_size)
    TextView tvDdrSize;
    @BindView(R.id.text_emmc_size)
    TextView tvEmmcSize;
    @BindView(R.id.text_emmc_real)
    TextView tvEmmcReal;
    @BindView(R.id.text_ln)
    TextView tvLN;
    @BindView(R.id.text_mac)
    TextView tvMac;
    @BindView(R.id.text_sn)
    TextView tvSn;
    @BindView(R.id.text_system_property)
    TextView tvSystemProperty;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baseinfo);
    }

    @Override
    protected void onResume() {
        super.onResume();

        initView();
    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }

    @OnClick({R.id.btn_back_baseinfo})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_baseinfo: {
                finish();
            }
        }
    }

    private void initView() {
        tvChipName.setText("芯片型号：" + SdkApi.getInstance().DeviceInfo().getChipName());
        tvDdrSize.setText("DDR大小：" + SdkApi.getInstance().DeviceInfo().getDDRSize());
        tvEmmcSize.setText("EMMC大小：" + SdkApi.getInstance().DeviceInfo().getEMMCSize());
        tvLN.setText("LN：" + SdkApi.getInstance().DeviceInfo().getLN());
        Log.i(TAG, "path = " + Environment.getExternalStorageDirectory());
        tvEmmcReal.setText("EMMC可用总大小：" + stroagePercent(Environment.getExternalStorageDirectory()) + "GB");
        tvMac.setText("Ethernet MAC：" + SdkApi.getInstance().DeviceInfo().getEthMac());
        tvSn.setText("SN：" + SdkApi.getInstance().DeviceInfo().getSerialNumber());

        String value = SdkApi.getInstance().DeviceInfo().getProperty("persist.vendor.custom_product", "none");
        tvSystemProperty.setText("客户节点：" + value);
    }

    private double stroagePercent(File file) {
        if (file == null || !file.exists()) {
            Log.i(TAG, "path = not exist");
            return -1;
        }

        if (!file.canRead()) {
            Log.i(TAG, "path = not read");
            return -1;
        }

        double size = FormetFloat(getTotalBlocks(file) / 1024 / 1024 / 1024);
        Log.i(TAG, "path size = " + size);
        if (size == 1.88 || size == 0.97 || size == 0.98 || size == 0.0 || size == 1.95 || size == 0.49 || size == 0.96 || size == 0.48) {
            return -1;
        }
        return size;
    }

    private Double FormetFloat(float text) {
        DecimalFormat fmt = new DecimalFormat("0.##");
        String aa = fmt.format(text);
        return Double.parseDouble(aa);
    }

    private float getTotalBlocks(File file) {
        final StatFs stat = new StatFs(file.getPath());
        //获取U盘总空间
        long totalSize = stat.getTotalBytes();
        return totalSize;
    }
}
