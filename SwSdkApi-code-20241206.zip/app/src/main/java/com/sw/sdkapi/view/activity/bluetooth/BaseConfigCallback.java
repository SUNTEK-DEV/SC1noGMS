package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothDevice;

public interface BaseConfigCallback {

    /**
     * 蓝牙开关
     * @param state
     */
    void onStateSwitch(int state);

    /**
     * 搜索设备结束
     */
    void onScanStop();

    /**
     * 发现新设备
     * @param device
     */
    void onFindDevice(BluetoothDevice device, int rssi);

    /**
     * 连接设备
     * @param device
     */
    void onConnect(BluetoothDevice device);
}
