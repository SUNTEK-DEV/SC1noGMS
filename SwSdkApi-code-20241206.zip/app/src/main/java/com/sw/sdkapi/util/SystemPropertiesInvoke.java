package com.sw.sdkapi.util;

import android.util.Log;

import java.lang.reflect.Method;

public class SystemPropertiesInvoke {
    private static final String TAG = "SystemPropertiesInvoke";
    private static Method getMethod = null;
    private static Method setMethod = null;

    public static String get(final String key, final String def) {
        try {
            if (getMethod == null) {
                getMethod = Class.forName("android.os.SystemProperties")
                        .getMethod("get", String.class, String.class);
            }
            return (String) getMethod.invoke(null, key, def);
        } catch (Exception e) {
            Log.e(TAG, "Platform error:" + e.toString());
            return def;
        }
    }

    public static void set(final String key, final String val) {
        try {
            if (setMethod == null) {
                setMethod = Class.forName("android.os.SystemProperties")
                        .getMethod("set", String.class, String.class);
            }
            setMethod.invoke(null, key, val);
        } catch (Exception e) {
            Log.e(TAG, "Platform error:" + e.toString());
        }
    }
}
