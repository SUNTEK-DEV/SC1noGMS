package com.sw.sdkapi.view.activity;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;

import androidx.annotation.Nullable;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ApiTool;
import com.sdkapi.sdkapiservice.ISdkCommonListener;
import com.sw.sdkapi.BaseActivity;
import com.sw.sdkapi.R;

import android.os.Process;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.OnClick;

public class NetworkActivity extends BaseActivity {

    private final String TAG = "NetworkActivity";

    @BindView(R.id.text_wifi_signal_data)
    TextView tvWifiSignal;

    int pid;
    int[] array = new int[]{11, 2};

    private Handler handler = new Handler();
    private boolean isStop = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_network);
        pid = Process.myPid();
        SdkApi.getInstance().CommonEvent().registerCommonListener(pid, commonListener);
    }

    @Override
    protected void onResume() {
        super.onResume();

        handler.post(runnable);
    }

    @OnClick({R.id.btn_back_network,
            R.id.btn_network_open_ethernet, R.id.btn_network_close_ethernet,
            R.id.btn_network_open_wifi, R.id.btn_network_close_wifi,
            R.id.btn_network_get_bluetooth_mac, R.id.btn_network_get_eth_info})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_back_network: {
                finish();
            }
            break;
            case R.id.btn_network_open_ethernet: {
                Log.i(TAG, "onViewClicked: open ethernet");
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.SWITCH_ETH, "true", array, array.length);
            }
            break;
            case R.id.btn_network_close_ethernet: {
                Log.i(TAG, "onViewClicked: close ethernet");
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.SWITCH_ETH, "false", array, array.length);
            }
            break;
            case R.id.btn_network_open_wifi: {
                Log.i(TAG, "onViewClicked: open wifi");
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.SWITCH_WIFI, ApiTool.CommonEventConstant.SWITCH_OPEN, array, array.length);
            }
            break;
            case R.id.btn_network_close_wifi: {
                Log.i(TAG, "onViewClicked: close wifi");
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.SWITCH_WIFI, ApiTool.CommonEventConstant.SWITCH_CLOSE, array, array.length);
            }
            break;
            case R.id.btn_network_get_bluetooth_mac: {
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.GET_BLUETOOTH_MAC, "", array, array.length);
            }
            break;
            case R.id.btn_network_get_eth_info: {
                SdkApi.getInstance().CommonEvent().setCommonEvent(pid, ApiTool.CommonEvent.GET_ETH_INFO, "wifi", array, array.length);
            }
            break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SdkApi.getInstance().CommonEvent().unregisterCommonListener(pid, commonListener);
        isStop = true;
        handler.removeCallbacksAndMessages(null);
    }

    private ISdkCommonListener commonListener = new ISdkCommonListener.Stub() {
        @Override
        public void CommonListenerNotify(int actionId, String sVal, int[] iArray, int intArrayLen) throws RemoteException {
            Log.i(TAG, "CommonListenerNotify: ");
            int progress = intArrayLen;
            Log.i(TAG, "notify actionId = " + actionId + "; AppId = " + pid + "; sVal = " + sVal + "; progress = " + progress);
            if (actionId == ApiTool.CommonEvent.SWITCH_ETH) {  //以太网功能开关
                try {
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("以太网功能开关 = " + sVal);
                        }
                    }, 0);
                } catch (Exception e) {
//                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("以太网功能开关设置失败");
                        }
                    }, 0);
                }
            } else if (actionId == ApiTool.CommonEvent.SWITCH_WIFI) {
                try {
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("WIFI功能开关 = " + sVal);
                        }
                    }, 0);
                } catch (Exception e) {
//                    final int data = Integer.parseInt(sVal);
                    postUiRunnable(new Runnable() {
                        @Override
                        public void run() {
                            showToast("WIFI能开关设置失败");
                        }
                    }, 0);
                }
            } else if (actionId == ApiTool.CommonEvent.GET_BLUETOOTH_MAC) {
                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        showToast("蓝牙MAC = " + sVal);
                    }
                }, 0);
            } else if (actionId == ApiTool.CommonEvent.GET_ETH_INFO) {
                postUiRunnable(new Runnable() {
                    @Override
                    public void run() {
                        showToast("以太网信息 = " + sVal);
                    }
                }, 0);
            }
        }

        @Override
        public IBinder asBinder() {
            return super.asBinder();
        }
    };

    private void getWifiInfo(){
        WifiManager wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        wifiManager.getScanResults();
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        if ((wifiInfo != null) && (wifiInfo.getBSSID() != null)) {
            //wifi信号强度
            int signalLevel = WifiManager.calculateSignalLevel(wifiInfo.getRssi(), 5);

            Log.i(TAG, "wifi info = " + wifiInfo.toString());
            String data = "";
            data += ("SSID = " + wifiInfo.getSSID() + "\t\t");  //wifi名称
            data += ("RSSI = " + wifiInfo.getRssi() + "\t\t");
            data += ("SignalLevel = " + signalLevel + "\t\t");
            data += ("LinkSpeed = " + wifiInfo.getLinkSpeed() + WifiInfo.LINK_SPEED_UNITS);  //wifi速度

            tvWifiSignal.setText(data);
        }
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if(isStop){
                return;
            }

            getWifiInfo();

            handler.postDelayed(runnable, 5000);
        }
    };
}
