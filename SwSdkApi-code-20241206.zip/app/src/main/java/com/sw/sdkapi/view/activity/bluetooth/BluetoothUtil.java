package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class BluetoothUtil {

    /**
     * 获得蓝牙地址
     *
     * @return 蓝牙地址
     */
    public static String getBtAddressByReflection() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(bluetoothAdapter == null){
            return "00:00:00:00:00:00";
        }

        if(!bluetoothAdapter.isEnabled()){
            return "00:00:00:00:00:00";
        }

        return bluetoothAdapter.getAddress();
    }

    /**
     * 连接蓝牙
     */
    public static void connectBT(BluetoothDevice device){
        //判断设备是否配对，没有配对在配，配对了就不需要配了
        if (device.getBondState() == BluetoothDevice.BOND_NONE) {
            try {
                Method createBondMethod = device.getClass().getMethod("createBond");
                Boolean returnValue = (Boolean) createBondMethod.invoke(device);
                returnValue.booleanValue();
            } catch (Exception e) {
                // Auto-generated catch block
                e.printStackTrace();
            }
        }

        String pin = "1234";  //此处为你要连接的蓝牙设备的初始密钥，一般为1234或0000
        Method setPairingConfirmation = null;
        try {
            setPairingConfirmation = device.getClass().getDeclaredMethod("setPairingConfirmation", boolean.class);
            setPairingConfirmation.invoke(device, true);
            //3.调用setPin方法进行配对...
            Method removeBondMethod = device.getClass().getDeclaredMethod("setPin", new Class[]{byte[].class});
            Boolean returnValue = (Boolean) removeBondMethod.invoke(device, new Object[]{pin.getBytes()});
        } catch (NoSuchMethodException e) {

            e.printStackTrace();
        } catch (IllegalAccessException e) {

            e.printStackTrace();
        } catch (InvocationTargetException e) {

            e.printStackTrace();
        }
    }
}
