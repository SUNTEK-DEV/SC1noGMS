package com.sw.sdkapi.view.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Choreographer;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.sdkapi.api.SdkApi;
import com.sdkapi.common.ResultCallback;
import com.sdkapi.common.ResultInfo;
import com.sw.sdkapi.util.ApiConvertUtil;
import com.sw.sdkapi.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * 需要 bitmap 根据屏幕角度旋转
 * map 宽高，起始点位，以横屏为基准，自动旋转
 */
public class AmlogicActivity extends AppCompatActivity {
    private static final String TAG = "AmlogicActivity";
    boolean flagFocusOn = false;
    int rotate = 0;

    EditText eText_w, eText_h, eText_x, eText_y, eText_speed, eText_dir, eText_content;
    Button btn_test;
    private final static int DIRECTION_LEFT = 1;
    private final static int DIRECTION_RIGHT = 2;
    private final static int DIRECTION_UP = 3;
    private final static int DIRECTION_DOWN = 4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amlogic);
//        test();
        initView();
        SdkApi.newInstance(this);
        SdkApi.getInstance().Display().getScreenRotate(0, new ResultCallback<ResultInfo<Integer>>() {
            @Override
            public void onMsg(ResultInfo<Integer> val) {
                if (val == null) {
                    return;
                }
                rotate = val.getVal();
                Log.e(TAG, "onMsg: rotate=" + rotate);
                String str = ApiConvertUtil.getResultStr(val.getVal(), val.getStatus());
                Log.e(TAG, "onMsg: 当前屏幕方向" + str);

            }
        });

    }

    private void initView() {
        eText_w = findViewById(R.id.eText_w);
        eText_h = findViewById(R.id.eText_h);
        eText_x = findViewById(R.id.eText_x);
        eText_y = findViewById(R.id.eText_y);
        eText_speed = findViewById(R.id.eText_speed);
        eText_dir = findViewById(R.id.eText_dir);
        eText_content = findViewById(R.id.eText_content);
        btn_test = findViewById(R.id.btn_start);
        btn_test.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                setDarkTheme(false);
                new Thread(new Runnable() {/////todo 不使用new thread 方式，
                    @Override
                    public void run() {
                        Log.d("sw", "will start overlay");
                        String contentStr = "南京欣威视通科技有限公司致力于为您提供一流的科技解决方案！作为业内领先的科技企业，我们专注于智能监控、网络通信、工业自动化等领域，致力于为客户提供最优质的产品和服务。";
                        if (eText_content.getText() != null) {
                            contentStr = eText_content.getText().toString();
                        }
                        Bitmap data = createSubtitle(contentStr);
                        transferBitmapData(data);

                        int[] intArray = getScreenSize();
                        int mScreenWidth = intArray[0];
                        int mScreenHigh = intArray[1];
                        int x = 200;//偏移量x
                        int y = 500;//偏移量y
                        try {
                            x = Integer.parseInt(eText_x.getText().toString());
                            y = Integer.parseInt(eText_y.getText().toString());
                        } catch (Exception e) {

                        }

                        /**
                         * 画布 ：
                         */
//                        int mapWidth = mScreenWidth;
                        int mapWidth = 500;
                        int mapHigh = 50;
                        try {
                            mapWidth = Integer.parseInt(eText_w.getText().toString());
                            mapHigh = Integer.parseInt(eText_h.getText().toString());
                        } catch (Exception e) {

                        }
                        //////////这个高度就是字体大小，mapHigh == textHeight，  注意，4K  时，乘以2？？
                        Log.e(TAG, "run: overlay_drm_open liufeng0910");
                        SdkApi.getInstance().Other().overlay_drm_open(mapWidth, mapHigh, x, y);

                        Looper.prepare();
                        Log.d(TAG, "ismain-->" + (Looper.getMainLooper().getThread().getId() == Thread.currentThread().getId()));
                        Choreographer.getInstance().postFrameCallback(frameCallback);
                        Looper.loop();

                        Log.d("sw", "will close overlay");
                    }
                }).start(); // 启动线程
            }
        });
    }
//    private void setDarkTheme(boolean enable) {
//        if (enable) {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
//        } else {
//            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
//        }
//    }
//    private void test() {
//        TextView scrollingTextView = findViewById(R.id.scrollingTextView);
//        scrollingTextView.setMovementMethod(new ScrollingMovementMethod());
//        scrollingTextView.setText("需要滚动显示的新字幕。");
//        scrollingTextView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
//        scrollingTextView.setSingleLine(true);
//        scrollingTextView.setFocusable(true);
//        scrollingTextView.setFocusableInTouchMode(true);
//        scrollingTextView.requestFocus();
//        scrollingTextView.setSelected(true);
//    }

    private Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            // 在这里实现每一帧的处理逻辑
            // 比如更新动画、刷新UI等
            // 在每帧结束后继续请求下一帧
            if (flagFocusOn) {//不添加会出现 加速
                //dir   方向，当前默认横向    1向左    2向右，ok         3向上 和  4向下。 异常
                //dir   方向，       竖向时   1向左    2向右，ok         3向上 和  4向下。 异常
                int speed = 4;
                int dir = 1;
                try {
                    speed = Integer.parseInt(eText_speed.getText().toString());
                    dir = Integer.parseInt(eText_dir.getText().toString());
                } catch (Exception e) {

                }
                SdkApi.getInstance().Other().overlay_drm_show(speed, dir);//speed   速度 /////为啥是外面调用，不是自调
                /**
                 * 横屏   1   2    可以。   3   4不可以
                 *
                 * 竖屏   1   2    可以    3   4  待验证
                 */

                Log.e(TAG, "doFrame: overlay_drm_show");
                Choreographer.getInstance().postFrameCallback(this);
            }
        }
    };

    @Override
    protected void onPause() {
        super.onPause();
        flagFocusOn = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        flagFocusOn = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 停止任何正在运行的 Choreographer 回调
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        // 执行其他清理操作，例如关闭 Overlay
        SdkApi.getInstance().Other().overlay_drm_close();  // 假设你有一个方法来关闭 DRM Overlay
        Log.d(TAG, "Overlay DRM closed");
        Log.d(TAG, "MainActivity is being destroyed");
    }


    public Bitmap rotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle); // 设定旋转角度

        // 使用 createBitmap 方法创建一个新的 Bitmap 对象
//        if (isLand) {
//            return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
//        } else {
//            return Bitmap.createBitmap(source, 0, 0, source.getHeight(), source.getWidth(), matrix, true);
//        }
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void saveBitmap(String filePath, Bitmap bitmap) {
        File file = new File(filePath);
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(file);
            // 将 Bitmap 压缩为 PNG 格式，并写入到文件中
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            System.out.println("PNG file saved successfully: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 左右滚动，   画布高度与bitmap等高，
     * 上下滚动，   画布宽度与bitmap等宽，
     */
    @SuppressLint("WrongConstant")
    private Bitmap createSubtitle(String text) {
        int textWidth;
        int textHeight = 50;//liufeng_check,,,,100  可以自己设定大小，大小不超过 横屏下 overlay_drm_open(mapWidth, mapHigh, x, y)的mapHigh参数
        try {
            textHeight = Integer.parseInt(eText_h.getText().toString());/////非绑定关系可以和map不一样大小，《=
        } catch (Exception e) {

        }

        Bitmap bitmap;
        // 定义背景颜色和文本颜色的 Paint 对象
        Paint bgRect = new Paint();
        bgRect.setStyle(Paint.Style.FILL);
        bgRect.setColor(Color.GRAY);//liufeng_check

        Paint textPaint = new Paint();
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setStrokeWidth(8);//liufeng_check
        textPaint.setTextSize(textHeight);//liufeng_check
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setAntiAlias(true);
        textPaint.setColor(Color.RED);//liufeng_check
        textWidth = (int) textPaint.measureText(text);
        bitmap = Bitmap.createBitmap(textWidth + 1, textHeight, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        if (!TextUtils.isEmpty(eText_dir.getText())) {
            if (eText_dir.getText().toString().equals("3") || eText_dir.getText().toString().equals("4")) {
                try {
                    int tempTextWidth = Integer.parseInt(eText_w.getText().toString());/////非绑定关系可以和map不一样大小，《=
                    textHeight = textHeight * ((int) Math.ceil(textWidth / tempTextWidth));
                    textWidth = tempTextWidth;
                    //////左右滚动
                    bitmap = Bitmap.createBitmap(textWidth + 1, textHeight, Bitmap.Config.ARGB_8888);
                    c = new Canvas(bitmap);
                    c.drawColor(Color.TRANSPARENT);


                    // 计算基线，使文本垂直居中
                    Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
                    float distance = (fontMetrics.bottom - fontMetrics.top) / 2 - fontMetrics.bottom;
                    float baseline = textHeight / 2 + distance;
                    c.drawText(text, textWidth / 2, baseline, textPaint);

                    // 计算每行文字的高度
                    Rect bounds = new Rect();
                    textPaint.getTextBounds("A", 0, 1, bounds);
                    int lineHeight = bounds.height();

                    // 分割多行文字
                    String[] lines = text.split("\n");

                    // 绘制每行文字
                    int y = lineHeight;
                    for (String line : lines) {
                        c.drawText(line, 0, y, textPaint);
                        y += lineHeight + 10; // 行间距
                    }
                } catch (Exception e) {

                }
// TODO: 2024/9/19
            } else {
                //////左右滚动
                // 绘制背景矩形
//        RectF rectF = new RectF(0, 0, textWidth, textHeight);
//        c.drawRect(rectF, bgRect);
                c.drawColor(Color.TRANSPARENT);

                // 计算基线，使文本垂直居中
                Paint.FontMetrics fontMetrics = textPaint.getFontMetrics();
                float distance = (fontMetrics.bottom - fontMetrics.top) / 2 - fontMetrics.bottom;
                float baseline = textHeight / 2 + distance;
                c.drawText(text, textWidth / 2, baseline, textPaint);
            }
        } else {
            Log.e(TAG, "createSubtitle: eText_dir param error");
        }

//        // 获取位图的字节数组
//        int bytesLength = bitmap.getByteCount();
//        ByteBuffer buffer = ByteBuffer.allocate(bytesLength);
//        bitmap.copyPixelsToBuffer(buffer);
//        byte[] data = buffer.array();
        Bitmap rotatedBitmap = rotateBitmap(bitmap, rotate);
        // 打印位图的字节数据
//        Log.d(TAG, "bitmap: " + byteToString(data, 100));
        Log.d(TAG, "bitmap w:" + textWidth);
        saveBitmap("/sdcard/1.png", bitmap);
        saveBitmap("/sdcard/2.png", rotatedBitmap);
        if (rotate == 0) {
            return bitmap;
        }
        return rotatedBitmap;
    }

    private int[] getScreenSize() {
        // 获取屏幕宽度和高度
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        Log.i(TAG, "getScreenSize: width= " + width);
        Log.i(TAG, "getScreenSize: height= " + height);
        return new int[]{width, height};
    }

    @SuppressLint("WrongConstant")
    public void transferBitmapData(Bitmap bitmap) {
        final int CHUNK_SIZE = 500 * 1024;//////liufeng_check
        int totalsize = bitmap.getByteCount();

        ByteBuffer buffer = ByteBuffer.allocate(totalsize);
        bitmap.copyPixelsToBuffer(buffer);
        byte[] bitmapData = buffer.array();

        int offset = 0;
        int chunkId = 1;

        while (offset < totalsize) {
            int remainingsize = totalsize - offset;
            int chunkSize = Math.min(CHUNK_SIZE, remainingsize);
            byte[] chunk = new byte[chunkSize];

            System.arraycopy(bitmapData, offset, chunk, 0, chunkSize);
            Log.d(TAG, "chunkSize:" + chunkSize);
            SdkApi.getInstance().Other().overlay_drm_transfer_data(chunkId, chunk, chunkSize);
            if (chunkId == 1)
                chunkId = 2;
            offset += chunkSize;
        }
    }
}