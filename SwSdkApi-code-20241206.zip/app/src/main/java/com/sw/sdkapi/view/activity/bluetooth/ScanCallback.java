package com.sw.sdkapi.view.activity.bluetooth;

import android.bluetooth.BluetoothDevice;

import java.util.List;

public interface ScanCallback {

    /**
     * 开始搜索设备
     * true 成功
     * false 失败
     * @parm isOn
     */
    void onScanStart(boolean isOn);

    /**
     * 搜索结果
     *
     * @param deviceList
     */
    void onScanStop(List<BluetoothDeviceInfo> deviceList);

    /**
     * 发现新设备
     * @param device
     */
    void onFindDevice(BluetoothDevice device, int rssi);

}
