package com.sw.serial;

public interface ISerialCallback {
    int openSerial(String device, int baudRate);

    void closeSerial(int fd);

    int readSerial(int serial, byte[] buf, int offset, int len);

    int writeSerial(int serial, byte[] buf, int offset, int len);

    int available();
}
