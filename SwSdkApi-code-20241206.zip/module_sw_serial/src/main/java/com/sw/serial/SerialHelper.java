package com.sw.serial;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.security.InvalidParameterException;
import java.util.Arrays;

public abstract class SerialHelper {
    private final String TAG = "SerialHelper";

    private ISerialCallback mSerialPort;
    private ReadThread mReadThread;
    private String mPort;
    private int mBaudRate;
    private boolean mbIsOpen;
    private byte[] mLoopData;
    private int iDelay;
    private boolean isStop = false;
    private boolean isParallel = true;

    public int serialFd = -1;//串口句柄

    public SerialHelper(String port, int baudRate) {
        initData(port, baudRate, true);//默认并行
    }

    public SerialHelper(String port, int baudRate, boolean isParallel) {
        initData(port, baudRate, isParallel);
    }

    private void initData(String port, int baudRate, boolean isParallel) {
        this.mbIsOpen = false;
        this.iDelay = 500;
        this.mPort = port;
        this.mBaudRate = baudRate;
        isStop = false;
        this.isParallel = isParallel;
    }

    public void open() throws SecurityException, IOException, InvalidParameterException {
        Log.d(TAG, "serial open");
        this.mSerialPort = new SerialPort(new File(this.mPort), this.mBaudRate, 0);
        //开启线程读取串口数据
        this.mReadThread = new ReadThread();
        this.mReadThread.start();
        this.mbIsOpen = true;
    }

    /**
     * 获取串口句柄
     *
     * @return
     */
    public int serialId() {
        return this.mSerialPort.openSerial(mPort, mBaudRate);
    }

    public void close() {
        isStop = true;
        synchronized (SerialHelper.this) {
            if (this.mSerialPort != null) {
                this.mSerialPort.closeSerial(serialFd);
                this.mSerialPort = null;
                this.serialFd = -1;
            }
        }

        this.mbIsOpen = false;
    }

    public boolean send(byte[] data) throws IOException {
        if (mSerialPort != null) {
            int temp = mSerialPort.writeSerial(serialFd, data, 0, data.length);
            return true;
        } else {
            return false;
        }
    }

    public int send(byte[] data, int length) throws IOException {
        if (mSerialPort != null) {
            return mSerialPort.writeSerial(serialFd, data, 0, length);
        } else {
            return 0;
        }
    }

    public int send(byte[] data, int offset, int length) throws IOException {
        if (mSerialPort != null) {
            return mSerialPort.writeSerial(serialFd, data, offset, length);
        } else {
            return 0;
        }
    }

    public void sendHex(String hex) throws IOException {
        byte[] bOutArray = hexToByteArr(hex);
        this.send(bOutArray);
    }

    public void sendTxt(String text) throws IOException {
        byte[] bOutArray = text.getBytes();
        this.send(bOutArray);
    }

    public int isOdd(int num) {
        return num & 1;
    }

    public byte hexToByte(String hex) {
        return (byte)Integer.parseInt(hex, 16);
    }

    public byte[] hexToByteArr(String hex) {
        int nLen = hex.length();
        byte[] result;
        if (isOdd(nLen) == 1) {
            ++nLen;
            result = new byte[nLen / 2];
            hex = "0" + hex;
        } else {
            result = new byte[nLen / 2];
        }

        int j = 0;

        for(int i = 0; i < nLen; i += 2) {
            result[j] = hexToByte(hex.substring(i, i + 2));
            ++j;
        }

        return result;
    }

    public int getBaudRate() {
        return this.mBaudRate;
    }

    public boolean setBaudRate(int baudRate) {
        if (this.mbIsOpen) {
            return false;
        } else {
            this.mBaudRate = baudRate;
            return true;
        }
    }

    public boolean setBaudRate(String baudRate) {
        int iBaud = Integer.parseInt(baudRate);
        return this.setBaudRate(iBaud);
    }

    public String getPort() {
        return this.mPort;
    }

    public boolean setPort(String port) {
        if (this.mbIsOpen) {
            return false;
        } else {
            this.mPort = port;
            return true;
        }
    }

    public boolean isOpen() {
        return this.mbIsOpen;
    }

    public byte[] getLoopData() {
        return this.mLoopData;
    }

    public void setbLoopData(byte[] loopData) {
        this.mLoopData = loopData;
    }

    public void setTxtLoopData(String text) {
        this.mLoopData = text.getBytes();
    }

    public void setHexLoopData(String hex) {
        this.mLoopData = hexToByteArr(hex);
    }

    public int getiDelay() {
        return this.iDelay;
    }

    public void setiDelay(int delay) {
        this.iDelay = delay;
    }

    public void resumeSend() {
    }

    protected abstract void onReceive(SerialHelper helper, byte[] buffer, int length);

    /**
     * 读数据
     */
    private class ReadThread extends Thread {

        public void run() {
            super.run();

            if (isParallel) {
                // 1K -> 4K  目标就是让这个数组里面充满数据 这个buffer 会读到之前设置的数据 但是不全 需要增加缓冲数组来接收
                byte[] buffer = new byte[1024];

                while (!isStop) {
                    try {
                        int size = 0;

                        synchronized (SerialHelper.this) {
                            if (SerialHelper.this.mSerialPort == null) {
                                break;
                            }

                            if (SerialHelper.this.mSerialPort.available() > 0) {
                                size = SerialHelper.this.mSerialPort.readSerial(SerialHelper.this.serialFd, buffer, 0, 1024);
                            }
                        }

                        if (size > 0) {
                            SerialHelper.this.onReceive(SerialHelper.this, buffer, size);
                        }
                        Thread.sleep(50L);
                    } catch (Exception e) {
                        Log.d(TAG, "run: exception = " + e.toString());
                        continue;
                    }
                }
            } else {
                Log.d(TAG, "run: not isParallel");
                if (SerialHelper.this.mSerialPort == null) {
                    Log.d(TAG, "run: --- SerialHelper.this.mInputStream = null");
                    return;
                }

                int size = 0;
                byte[] buffer = new byte[1024];
                byte[] mTempBuffer;
                while (true) {
                    synchronized (SerialHelper.this) {
                        if (SerialHelper.this.mSerialPort == null) {
                            break;
                        }

                        int len = SerialHelper.this.mSerialPort.readSerial(SerialHelper.this.serialFd, buffer, size, 128);
                        if (len > 0) {
                            size += len;
                        }
                    }

                    delay(1);
                    Log.d(TAG, "size = " + size + " SerialHelper is: " + SerialHelper.this);

                    if (size >= 128) {
                        break;
                    }
                }

                if (size > 0) {
                    mTempBuffer = new byte[size];
                    System.arraycopy(buffer, 0, mTempBuffer, 0, size);
                    Log.d(TAG, "buffer = " + Arrays.toString(mTempBuffer));

                    SerialHelper.this.onReceive(SerialHelper.this, buffer, size);
                }
            }
        }
    }

    public void delay(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
