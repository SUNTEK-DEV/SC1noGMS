package com.sw.serial;

import android.util.Log;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class SerialPort implements ISerialCallback {
    private final String TAG = "SerialPort";

    private FileDescriptor mFd;
    private FileInputStream mFileInputStream;
    private FileOutputStream mFileOutputStream;

    public SerialPort(File device, int baudrate, int flags) throws SecurityException, IOException {
        Log.d(TAG, "device read = " + device.canRead() + "; write = " + device.canWrite());

        if (!device.canRead() || !device.canWrite()) {
            try {
                //赋予su权限操作
                Process su = Runtime.getRuntime().exec("/system/bin/su");
                String cmd  = "chmod 666 " + device.getAbsolutePath() + "\nexit\n";
                Log.i(TAG,"SerialPort --- > cmd : " + cmd);

                su.getOutputStream().write(cmd.getBytes());
                if (su.waitFor() != 0 || !device.canRead() || !device.canWrite()) {
                    throw new SecurityException();
                }
            } catch (Exception var6) {
                var6.printStackTrace();
                throw new SecurityException();
            }
        }

        this.mFd = open(device.getAbsolutePath(), baudrate, flags);

        Log.d(TAG, "SerialPort: ------ the next is mFd = " + this.mFd);
        if (this.mFd == null) {
            Log.e("SerialPort", "native open returns null");
            throw new IOException();
        } else {
            this.mFileInputStream = new FileInputStream(this.mFd);
            this.mFileOutputStream = new FileOutputStream(this.mFd);
        }
    }

    public InputStream getInputStream() {
        return this.mFileInputStream;
    }

    public OutputStream getOutputStream() {
        return this.mFileOutputStream;
    }

    private static native FileDescriptor open(String var0, int var1, int var2);

    public native void close();

    public int openSerial(String device, int baudRate){
        return -1;
    }

    public void closeSerial(int fd){
        if(mFileInputStream != null){
            try {
                mFileInputStream.close();
            } catch (IOException e) {

            }
            mFileInputStream = null;
        }

        if(mFileOutputStream != null){
            try {
                mFileOutputStream.close();
            } catch (IOException e) {

            }
            mFileOutputStream = null;
        }

        close();
    }

    public int readSerial(int serial, byte[] buf, int offset, int len){
        try {
            if((offset + len) > buf.length){
                len = buf.length - offset;
            }

            return this.mFileInputStream.read(buf, offset, len);
        }catch (Exception e){

        }

        return 0;
    }

    public int writeSerial(int serial, byte[] buf, int offset, int len) {
//        Log.d(TAG, "writeSerial: ---> serial = " + Arrays.toString(buf));
        try {
            if (this.mFileOutputStream != null) {
                this.mFileOutputStream.write(buf, offset, len);

                return len;
            }
        }catch (Exception e){
            Log.d(TAG, "writeSerial: buf error = " + e.toString());
        }

        return 0;
    }

    public int available(){
        try {
            return this.mFileInputStream.available();
        }catch (Exception e){
            return 0;
        }
    }

    static {
        System.loadLibrary("serial_port");
    }
}
